package newfeatures;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsAndTab {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.get("https://www.persistent.com/");
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		
		Set <String> windows=driver.getWindowHandles(); 
		List<String> list=new ArrayList<String>(windows);	
		
		driver.switchTo().newWindow(WindowType.WINDOW); //opening new window
		driver.get("https://en.wikipedia.org/wiki/Persistent_Systems");
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		
		driver.close(); //closing the current window
		driver.switchTo().window(list.get(0)); // switching to old window
		Thread.sleep(3000);
		driver.quit();
	}

}
