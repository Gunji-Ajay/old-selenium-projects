package testNg;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class basic4 {
	
	@Test(dataProvider="getdata")
	public static void main(String url, String password) {
		// TODO Auto-generated method stub
		System.out.println("getting url and password for Basic4");
		System.out.println(url);
		System.out.println(password);
		
	}
	
	@BeforeTest
	public static void before() {
		// TODO Auto-generated method stub
		System.out.println("BeforeTest started reading credentials on BeforeTest for Basic4");
		
		
	}
	
	@AfterTest
	public static void after() {
		// TODO Auto-generated method stub
		System.out.println("AfterTest completed for Basic4");
		
		
	}
	
	
	
	@DataProvider
	public static Object[][] getdata() {
		Object[][] data=new Object[3][2];
		data[0][0]="firstUrl";
		data[0][1]="firstpassword";
		
		data[1][0]="firstUrl";
		data[1][1]="firstpassword";
		
		data[2][0]="firstUrl";
		data[2][1]="firstpassword";
		return data;
	}
	
	
	

}
