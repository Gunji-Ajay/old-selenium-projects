package testNg;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class basic3 {
	
	@Parameters({"prasanth2url", "prasanth2pass"})
	@Test
	public static void web(String url, String pass) {
		// TODO Auto-generated method stub
		System.out.println("login web page for Basic3");
		System.out.println("URL for prasanth1 mail: "+url+" for Basic3");
		System.out.println("password for prasanth1 mail: "+pass+" for Basic3");
	}
	
	@Test
	public static void mobile() {
		// TODO Auto-generated method stub
		System.out.println("mobile for Basic3");
	}
	
	@Test
	public static void mobile1() {
		// TODO Auto-generated method stub
		System.out.println("mobile1 for Basic3");
		Assert.assertTrue(true);
	}
	
	@Test
	public static void mobilein() {
		// TODO Auto-generated method stub
		System.out.println("mobilein for Basic3");
	}
	@BeforeTest
	public static void mobileout() {
		// TODO Auto-generated method stub
		System.out.println("BeforeTest mobileout  for Basic3");
	}
	
	@AfterTest
	public static void desktop() {
		// TODO Auto-generated method stub
		System.out.println("AfterTest desktop for Basic3");
	}
	
	@BeforeSuite
	public static  void Beforesubject1() {
		// TODO Auto-generated method stub
		System.out.println("BeforeSuite for Basic3");
	}
	
	@AfterSuite
	public static  void Aftersubject1() {
		// TODO Auto-generated method stub
		System.out.println("AfterSuite for Basic3");
	}
	
	@BeforeMethod
	public static void method() {
		System.out.println("BeforeMethod for Basic3");
	}
	
	@AfterMethod
	public static void method1() {
		System.out.println("AfterMethod for Basic3");
	}
	
	@BeforeClass
	public static  void beforeclass() {
		// TODO Auto-generated method stub
		System.out.println("BeforeClass for Basic3");
	}
	
	@AfterClass
	public static  void afterclass() {
		// TODO Auto-generated method stub
		System.out.println("AfterClass for Basic3");
	}
	

}
