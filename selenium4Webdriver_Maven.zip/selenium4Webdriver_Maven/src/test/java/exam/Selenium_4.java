package exam;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
//import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Selenium_4 {
    public static WebDriver driver;
	public static String baseUrl = "https://app.e-box.co.in/uploads/base_projects/20983_index.html";
	public static String emptyErrMsg;
	public static String passwordErrMsg;
	public static String emailErrMsg;
	public static String phoneErrMsg;
	public static String successMsg;
	@BeforeTest
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}
	
	//fill your code here
	@Test (priority=1)
	public void emptyFieldsCheck() throws Exception{
		//fill your code here
		driver.findElement(By.name("name")).sendKeys("");
		driver.findElement(By.name("password")).sendKeys("");
		driver.findElement(By.name("phoneNumber")).sendKeys("");
		driver.findElement(By.name("email")).sendKeys("");
		driver.findElement(By.name("city")).sendKeys("");
		driver.findElement(By.name("password")).sendKeys("");
		driver.findElement(By.id("submit")).click();
		emptyErrMsg=driver.findElement(By.id("result")).getText();
		
		//System.out.println(emptyErrMsg);
		
	}

	@Test (priority=2)
	public void passWordCheck() throws Exception{
		//fill your code here
		driver.findElement(By.name("name")).clear();
		driver.findElement(By.name("name")).sendKeys("John");

		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("John smith");

		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("John");

		driver.findElement(By.name("phoneNumber")).clear();
		driver.findElement(By.name("phoneNumber")).sendKeys("9856327987");

		driver.findElement(By.name("email")).clear();
		driver.findElement(By.name("email")).sendKeys("john@gmail.com");

		driver.findElement(By.name("city")).clear();
		driver.findElement(By.name("city")).sendKeys("chennai");

		driver.findElement(By.id("submit")).click();
		passwordErrMsg=driver.findElement(By.id("result")).getText();
		
		//System.out.println(passwordErrMsg);
	}			

	@Test (priority=3)
	public void emailCheck() throws Exception{
		//fill your code here
		driver.findElement(By.name("name")).clear();
		driver.findElement(By.name("name")).sendKeys("John");

		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("John smith");

		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("Johnsmith");

		driver.findElement(By.name("phoneNumber")).clear();
		driver.findElement(By.name("phoneNumber")).sendKeys("9856327987");

		driver.findElement(By.name("email")).clear();
		driver.findElement(By.name("email")).sendKeys("john.com");

		driver.findElement(By.name("city")).clear();
		driver.findElement(By.name("city")).sendKeys("chennai");

		driver.findElement(By.id("submit")).click();
		emailErrMsg=driver.findElement(By.id("result")).getText();
		
		//System.out.println(emailErrMsg);
	}

	@Test (priority=4)
	public void phoneNoCheck() throws Exception{
		//fill your code here
		driver.findElement(By.name("name")).clear();
		driver.findElement(By.name("name")).sendKeys("John");

		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("John smith");

		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("Johnsmith");

		driver.findElement(By.name("phoneNumber")).clear();
		driver.findElement(By.name("phoneNumber")).sendKeys("9856327");

		driver.findElement(By.name("email")).clear();
		driver.findElement(By.name("email")).sendKeys("john@gmail.com");

		driver.findElement(By.name("city")).clear();
		driver.findElement(By.name("city")).sendKeys("chennai");

		driver.findElement(By.id("submit")).click();
		phoneErrMsg=driver.findElement(By.id("result")).getText();	
		
		//System.out.println(phoneErrMsg);
		}
	

	@Test (priority=5)
	public void userDetailCheck() throws Exception{
		//fill your code here
		driver.findElement(By.name("name")).clear();
		driver.findElement(By.name("name")).sendKeys("John");

		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("John smith");

		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("Johnsmith");

		driver.findElement(By.name("phoneNumber")).clear();
		driver.findElement(By.name("phoneNumber")).sendKeys("9856327867");

		driver.findElement(By.name("email")).clear();
		driver.findElement(By.name("email")).sendKeys("john@gmail.com");

		driver.findElement(By.name("city")).clear();
		driver.findElement(By.name("city")).sendKeys("chennai");

		driver.findElement(By.id("submit")).click();
		successMsg=driver.findElement(By.id("result")).getText();	
		
		//System.out.println(successMsg);
		}
	

	@AfterTest
	public void tearDown() throws Exception{
		//fill your code here
		driver.quit();
	}
	//fill your code here
}
