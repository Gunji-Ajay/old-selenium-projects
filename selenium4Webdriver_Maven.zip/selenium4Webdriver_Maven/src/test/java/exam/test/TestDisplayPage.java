package exam.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
//import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import exam.pages.UserPage;
import exam.pages.DisplayPage;;


public class TestDisplayPage {

	WebDriver driver;
	public static String url="https://app.e-box.co.in/uploads/base_projects/21096_index.html";
	public static String getH1tag ,result;
	//h1Element
	UserPage user;
	DisplayPage display;

	
	@BeforeMethod
	public void launchDriver() {
		driver = new FirefoxDriver();
		driver.get(url);
		user = new UserPage(driver);
		display = new DisplayPage(driver);
	}
	
	@Test
	public void testUserDetails() {
		
		user.setName("John");
		user.setEmail("john123@gmail.com");
		user.setPassword("john123");
		user.setAge("23");
		user.setRole("participant");
		user.clickSubmit();
	    getH1tag=display.getH1tag();
	    result=display.getResult();
	}


	@AfterMethod
	public void quitDriver() {
		driver.quit();
	}
}