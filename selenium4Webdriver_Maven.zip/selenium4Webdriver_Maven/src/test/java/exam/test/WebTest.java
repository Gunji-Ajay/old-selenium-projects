package exam.test;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.*;

public class WebTest {
	private WebDriver driver;
	public static String baseUrl="https://app.e-box.co.in/uploads/base_projects/21082_index.html";

	public static String h1;
	public static boolean usernamePresent=false;
	public static boolean passwordPresent=false;
	public static boolean loginbtnPresent=false;
	
	public static String msg1;
	public static String msg2;
	public static String msg3;
	public static String error;
	
	
	@BeforeTest
	public void setUp() throws Exception{
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MICROSECONDS);
	}
	
	@Test
	public void testWeb() throws Exception{
		driver.get(baseUrl);
		
		h1=driver.findElement(By.tagName("h1")).getText();
		usernamePresent=driver.findElement(By.name("username")).isDisplayed();
		passwordPresent=driver.findElement(By.name("password")).isDisplayed();
		loginbtnPresent=driver.findElement(By.id("login")).isDisplayed();
		
		driver.findElement(By.name("username")).sendKeys("eventOwner");
		driver.findElement(By.name("password")).sendKeys("event@123");
		driver.findElement(By.id("login")).click();
		msg1=driver.findElement(By.xpath("//div[@id='result']")).getText();
		
		driver.navigate().refresh();
		
		driver.findElement(By.name("username")).sendKeys("hallOwner");
		driver.findElement(By.name("password")).sendKeys("hall@123");
		driver.findElement(By.id("login")).click();
		msg2=driver.findElement(By.xpath("//div[@id='result']")).getText();
		
		driver.navigate().refresh();

		driver.findElement(By.name("username")).sendKeys("stallOwner");
		driver.findElement(By.name("password")).sendKeys("stall@123");
		driver.findElement(By.id("login")).click();
		msg3=driver.findElement(By.xpath("//div[@id='result']")).getText();
		
		driver.navigate().refresh();

		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin");
		driver.findElement(By.id("login")).click();
		error=driver.findElement(By.xpath("//p[@id='error']")).getText();
	}
	
	@AfterTest
	public void tearDown() throws Exception{
		//code
		driver.quit();
	}
}





//public static boolean isHeaderPresent=false;
//public static boolean isField1Present=false;
//public static boolean isField2Present=false;
//public static boolean isField3Present=false;
//public static boolean isField4Present=false;
//public static boolean isField5Present=false;
//public static boolean isButtonPresent=false;

//public static String rname="";
//public static String rusername="";
//public static String rmobile="";
//public static String raddress="";


//public static String baseUrl="https://app.e-box.co.in/uploads/base_projects/20997_index.html";


//code

//isHeaderPresent=driver.findElement(By.id("header")).isDisplayed();		
//isField1Present=driver.findElement(By.id("name")).isDisplayed();
//isField2Present=driver.findElement(By.id("username")).isDisplayed();	
//isField3Present=driver.findElement(By.id("password")).isDisplayed();
//isField4Present=driver.findElement(By.id("mobilenumber")).isDisplayed();
//isField5Present=driver.findElement(By.id("address")).isDisplayed();
//isButtonPresent=driver.findElement(By.id("register")).isDisplayed();
//
//driver.findElement(By.id("name")).sendKeys("Hazel");
//driver.findElement(By.id("username")).sendKeys("hazelgrace");
//driver.findElement(By.id("password")).sendKeys("12345");
//driver.findElement(By.id("mobilenumber")).sendKeys("123456789");
//driver.findElement(By.id("address")).sendKeys("chennai");
//driver.findElement(By.id("register")).click();
//
//rname=driver.findElement(By.xpath("//input[@type='text' and @id='name']")).getText();
//rusername=driver.findElement(By.xpath("//input[@type='text' and @id='username']")).getText();
//rmobile=driver.findElement(By.xpath("//input[@type='number' and @id='mobilenumber']")).getText();
//raddress=driver.findElement(By.xpath("//textarea[@type='text' and @id='address']")).getText();