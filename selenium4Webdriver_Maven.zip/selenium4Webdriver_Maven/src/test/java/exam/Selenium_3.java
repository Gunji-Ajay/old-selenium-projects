package exam;

import java.util.concurrent.TimeUnit;
//import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Selenium_3{
	private WebDriver driver;
	public static String baseUrl="http://app.e-box.co.in/uploads/Calculator_new.html";
	public static String addValue,subValue,mulValue,divValue;

	@BeforeTest
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}

	@Test//fill your code
	public void addition() throws Exception {
		//fill your code
		driver.findElement(By.id("value1")).sendKeys("100");
		driver.findElement(By.id("value2")).sendKeys("20");
		driver.findElement(By.name("add")).click();
		addValue=driver.findElement(By.id("result")).getText();	
	}

	@Test//fill your code
	public void subtraction() throws Exception {
		//fill your code
		driver.findElement(By.id("value1")).sendKeys("50");
		driver.findElement(By.id("value2")).sendKeys("10");
		driver.findElement(By.name("sub")).click();
		subValue=driver.findElement(By.id("result")).getText();
	}

	@Test//fill your code
	public void multiplication() throws Exception {
		//fill your code
		driver.findElement(By.id("value1")).sendKeys("5");
		driver.findElement(By.id("value2")).sendKeys("40");
		driver.findElement(By.name("mul")).click();
		mulValue=driver.findElement(By.id("result")).getText();		
	}

	@Test//fill your code
	public void division() throws Exception {
		//fill your code
		driver.findElement(By.id("value1")).sendKeys("1000");
		driver.findElement(By.id("value2")).sendKeys("10");
		driver.findElement(By.name("div")).click();
		divValue=driver.findElement(By.id("result")).getText();
	}


	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();

	}

}
