package POM_Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class properties {
	WebDriver driver;
	public WebDriver intializeDriver() throws IOException {
		// TODO Auto-generated method stub
		
		Properties prop= new Properties();
		FileInputStream file=new FileInputStream("./properties/data.properties");
		prop.load(file);
		String browser=prop.getProperty("driver");
		if (browser.equals("Chrome")) {
			driver=new ChromeDriver();
		}
		else if(browser.equals("FireFox")) {
			driver=new FirefoxDriver();
		}
		return driver;
		
	}
	public void getScreenshot(WebDriver driver) throws IOException {
		TakesScreenshot ss=(TakesScreenshot)driver;
		File Imgfile=ss.getScreenshotAs(OutputType.FILE);
		
		double RandomName = Math.random(); 
		FileUtils.copyFile(Imgfile, new File("./Screenshots/"+RandomName+".png"));
		System.out.println("the screenshot was successfully saved with this name:"+RandomName+".png");
	}
}
