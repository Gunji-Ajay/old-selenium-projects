package day8;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class XSSF_WorkBook {
	WebDriver driver;
  @Test
  public void f() throws IOException {
	  File src=new File("src/test/java/Input/XSSF_Demo.xlsx");
	  FileInputStream fileInput=new FileInputStream(src);
	  			  
	   Workbook wb = new XSSFWorkbook(fileInput);   
	   XSSFSheet sheet1 = (XSSFSheet) wb.getSheetAt(0);
	     
	   for(int i=1; i<=3; i++) {  
	   double playerNo = sheet1.getRow(i).getCell(0).getNumericCellValue();
	   String playerName = sheet1.getRow(i).getCell(1).getStringCellValue();
	   String playerCity = sheet1.getRow(i).getCell(2).getStringCellValue();
	     
	   System.out.println((int)playerNo + " "+ playerName + " " + playerCity);	  
	   }
	   System.out.println("Number of records "+sheet1.getLastRowNum());
  }
  @BeforeMethod
  public void beforeMethod() {
	  driver=new ChromeDriver();
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  Thread.sleep(1000);
	  driver.quit();
  }

}
