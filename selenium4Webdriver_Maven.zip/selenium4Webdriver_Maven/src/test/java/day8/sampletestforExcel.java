package day8;

import java.io.IOException;
import java.util.ArrayList;

public class sampletestforExcel {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		excelDrivenTest e=new excelDrivenTest();
		ArrayList<String> result = e.getdata("PrasanthKovvela");
		System.out.println(result);

	}

}
