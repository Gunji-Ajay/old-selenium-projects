package day8;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class YahooMail {
  WebDriver driver;
  @Parameters({"url", "username", "pass", "toMail", "Subject", "Message"})	
  @Test
  public void f(String url, String username, String pass, String toMail, String Subject, String Message) throws IOException, InterruptedException {	
	    WebDriver driver=new ChromeDriver();
	    driver.get(url);
	   
	    driver.findElement(By.xpath("//div[@class='text' and @title='Sign In']")).click();
		driver.findElement(By.id("login-username")).sendKeys(username);
		driver.findElement(By.id("login-signin")).click();
	    Thread.sleep(2000);
		driver.findElement(By.id("login-passwd")).sendKeys(pass);
		driver.findElement(By.id("login-signin")).click();		
		driver.findElement(By.cssSelector("div[title='Mail']")).click();
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("a[role='button']")).click();
		driver.findElement(By.cssSelector("input[aria-owns='react-typehead-list-to']")).sendKeys(toMail);
		driver.findElement(By.cssSelector("input[data-test-id='compose-subject']")).sendKeys(Subject);
		driver.findElement(By.cssSelector("div[data-test-id='rte']")).sendKeys(Message);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[title='Send this email']")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("span[ data-test-folder-name='Sent']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("ybar-logo")).click();
		Thread.sleep(2000);
		Actions mouseActions=new Actions(driver);
		mouseActions.moveToElement(driver.findElement(By.cssSelector("label[id='ybarAccountMenuOpener']"))).perform();
		Thread.sleep(2000);
		mouseActions.moveToElement(driver.findElement(By.id("profile-signout-link"))).click().perform();
	   
  }
  @BeforeMethod
  public void beforeMethod() {
	  driver=new ChromeDriver();
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
