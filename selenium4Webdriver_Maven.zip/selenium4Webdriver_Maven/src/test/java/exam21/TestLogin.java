package exam21;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import exam2.LoginPage;
import exam2.DisplayPage;


public class TestLogin {

	WebDriver driver;
	public static String url,result,h2tag;
	LoginPage ln;
	DisplayPage d;

	@BeforeMethod
	public void launchDriver() {
		driver = new FirefoxDriver();
		url = "http://app.e-box.co.in/uploads/userLogin.html";
		ln = new LoginPage(driver);
		d = new DisplayPage(driver);
	}

	@Parameters({"sUsername","sPassword"})
	@Test
	public void testLogin(String sUsername, String sPassword) {

		driver.get(url);
		ln.setName(sUsername);
		ln.setPassword(sPassword);
		ln.clickLogin();
		
		h2tag=d.getH2tag();
		result=d.getMessage();

	}

	@AfterMethod
	public void quitDriver() {
		driver.quit();
	}
}