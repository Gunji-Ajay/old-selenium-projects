package POM_TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import POM_Pages.HomePage;
import POM_Pages.LoginPage;



public class testcases {
	
	@Test
	public void login() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://in.search.yahoo.com/?fr2=inr");
		
		HomePage home=new HomePage(driver);
		home.homebutton().click();
		
		LoginPage login=new LoginPage(driver);
		login.userName().sendKeys("prasanthkovvela1");
		login.signinclick().click();
		Thread.sleep(3000);
		login.password().sendKeys("8096149628.K");
		login.signin().click();	
	}

}
