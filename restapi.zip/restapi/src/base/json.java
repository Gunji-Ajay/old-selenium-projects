package base;

import io.restassured.path.json.JsonPath;

public class json {
	public static JsonPath convertJson(String response) {
		JsonPath js1=new JsonPath(response);
		return js1;
	}

}
