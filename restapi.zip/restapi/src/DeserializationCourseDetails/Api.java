package DeserializationCourseDetails;

public class Api {
	
	private String courseTitle;
	private String price;
	
	
	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	public String getCourseTitle() {
		return courseTitle;
	}
	
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPrice() {
		return price;
	}


}
