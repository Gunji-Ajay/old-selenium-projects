package restapi;

import org.testng.Assert;

import base.BodyForPost;
import io.restassured.path.json.JsonPath;

public class ComplexJsonParse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JsonPath js1=new JsonPath(BodyForPost.coursesbody());
		int count=js1.getInt("courses.size()");
		System.out.println(count);
		
		int total=js1.getInt("dashboard.purchaseAmount");
		System.out.println(total);
		
		String courseTitle=js1.get("courses[0].title");
		System.out.println(courseTitle);
		
		
		int Total=0;
		for (int i=0; i<count; i++) {
			int eachCourse=js1.get("courses["+i+"].price");
			int BooksInEachCourse=js1.get("courses["+i+"].copies");
			Total+=eachCourse*BooksInEachCourse;
		}
		System.out.println(Total);
		Assert.assertEquals(Total, total);
	}
}
