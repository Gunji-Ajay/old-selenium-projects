package stepDefinations;

import java.io.IOException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.landingPage;
import pageObject.login;
import pageObject.sendMail;
import resources.base;

public class stepDefination extends base {
	
	@Given("initialize the browser with chrome")
	public void initialize_the_browser_with_chrome() throws IOException {
		driver = initialization();
	}
	
	@Given("navigate to {string} url")
	public void navigate_to_url(String url) {
		driver.get(url);
	    
	}
	
	@Given("click on login page")
	public void click_on_login_page() {
		landingPage main=new landingPage(driver); 
		main.button().click();
	    
	}
	
	@When("enter {string} and {string} and click login")
	public void enter_and_and_click_login(String username, String pass) {
		login lg=new login(driver); 
		lg.email().sendKeys(username);
		lg.emailclick().click();
		lg.password().sendKeys(pass);
		lg.passwordclick().click();	    
	}
	
	@Then("send a mail to {string} with subject {string} and message as {string}")
	public void send_a_mail_to_with_subject_and_message_as(String to, String subject, String body) {
	    // Write code here that turns the phrase above into concrete actions
		sendMail send=new sendMail(driver); //send mail page
		send.mailbtnclick().click();
		send.compose().click();
		send.tomail().sendKeys(to);
		send.subject().sendKeys(subject);
		send.message().sendKeys(body);
		send.send().click();
		System.out.println("mail send successfully");
	}
	
	@Then("close the browser")
	public void close_the_browser() {
		driver.close();
		System.out.println("browser closed successfully");
	}
	
	
}
