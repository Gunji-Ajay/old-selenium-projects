package validations;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import junit.framework.Assert;
import pageObject.landingPage;
import resources.base;


public class AssertValidation extends base{
	public WebDriver driver;
	private static Logger log=LogManager.getLogger(base.class.getName());

	@BeforeTest
	public void before1() throws IOException {
		driver = initialization();
		driver.get(prop.getProperty("url"));
	}
	
	@Test 
	public void firsttrailvalidation() throws IOException, InterruptedException 
	{		
		landingPage main=new landingPage(driver);
		Assert.assertEquals(main.title().getText(), "As of August 26th, 2021 Yahoo India will no longer be publishing content. Your Yahoo Account, Mail and Search experiences will not be affected in any way and will operate as usual. We thank you for your support and readership. For more information on Yahoo India, please visit the FAQ.");
		log.info("successfully matched the given titel with the url title");

	}
	
	@AfterTest
	public void After1() throws IOException {
		driver.close();
	}
	
	
}
