package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class login {
	
	WebDriver driver;
	public login(WebDriver driver) {
		this.driver=driver;
	}

	
	
	public WebElement email() {
		return driver.findElement(By.id("login-username"));
	}
	public WebElement emailclick() {
		return driver.findElement(By.name("signin"));
	}
	public WebElement password() {
		return driver.findElement(By.id("login-passwd"));
	}
	public WebElement passwordclick() {
		return driver.findElement(By.id("login-signin"));
	}
	
	
	
	

}
