package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class landingPage {

	
		WebDriver driver;		
		public landingPage(WebDriver driver) {
			// TODO Auto-generated constructor stub
			this.driver=driver;
		}
		
		public WebElement button() {
			return driver.findElement(By.xpath("//div[@title='Sign In']"));
		}
		
		public WebElement title() {
			return driver.findElement(By.id("promo-bd"));
		}
		
	}


