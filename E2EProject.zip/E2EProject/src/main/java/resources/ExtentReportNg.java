package resources;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportNg {
	static ExtentReports extent;
	
	public static ExtentReports Configuration() 
	{
		String path=System.getProperty("user.dir")+"\\reports\\index.html";
		
		ExtentSparkReporter report=new ExtentSparkReporter(path);
		report.config().setDocumentTitle("Test Results");
		report.config().setReportName("web Automation testing");
		
		extent=new ExtentReports();
		extent.attachReporter(report);
		extent.setSystemInfo("tester", "Prasanth Kovvela");
		return extent;
	}
	

}
