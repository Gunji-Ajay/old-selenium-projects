package resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.opentelemetry.exporter.logging.SystemOutLogExporter;



public class base {

	public WebDriver driver;
	public Properties prop;
	public  WebDriver initialization() throws IOException 
	{
		// TODO Auto-generated method stub

		prop=new Properties();
		File src=new File("src/main/java/resources/data.properties");
		FileInputStream file=new FileInputStream(src);
		prop.load(file);
				
		String browser=prop.getProperty("browser");

		System.out.println(browser);
		
		if (browser.equals("chrome")) 
		{
			driver=new ChromeDriver();
		}
		else if (browser.equals("firefox")) 
		{
			driver=new FirefoxDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}
	
	public String getScreenShot(String testCaseName, WebDriver driver) throws IOException {
		TakesScreenshot ss=(TakesScreenshot)driver;
		File Imgfile=ss.getScreenshotAs(OutputType.FILE);
		
//		double RandomName = Math.random(); 
//		FileUtils.copyFile(Imgfile, new File("./Screenshots/"+testCaseName+".png"));
		String destination=System.getProperty("user.dir")+"\\reports\\"+testCaseName+".png";
		FileUtils.copyFile(Imgfile, new File(destination));
		return destination;
	
	}

}
