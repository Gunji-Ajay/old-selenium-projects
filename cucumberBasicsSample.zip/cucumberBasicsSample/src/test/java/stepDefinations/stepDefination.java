package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefination {

	@Given("user is on netbanking loading page")
	public void user_is_on_netbanking_loading_page() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("user is on login page");
	}
	@When("user login into application with username and password")
	public void user_login_into_application_with_username_and_password() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("login details must be given");
	}
	@Then("home page is populated")
	public void home_page_is_populated() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("home page opened successfully");
	}
	@Then("cards are displayed")
	public void cards_are_displayed() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("cards was displaying");
	}
	
	
}
