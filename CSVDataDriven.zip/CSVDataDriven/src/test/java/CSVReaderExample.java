import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVReaderExample {

    public static void main(String[] args) {
        // Specify the path to your CSV file
        String csvFilePath = "C:\\Users\\adith\\OneDrive\\Documents\\incoming.csv";

        // Converting CSV to POJO classes
        List<MyData> dataList = convertCSVToPOJO(csvFilePath);

        // Processing data from POJO objects
        processDataFromPOJO(dataList);
    }

    private static List<MyData> convertCSVToPOJO(String filePath) {
        List<MyData> dataList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Skip header if present
            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                // Convert CSV data to POJO class
                MyData myData = new MyData(data[0], data[1], data[2], data[3], data[4]);
                dataList.add(myData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataList;
    }

    private static void processDataFromPOJO(List<MyData> dataList) {
        for (MyData myData : dataList) {
            // Access parameters from POJO object and pass into the code
            String parameter1 = myData.getCol1();
            String parameter2 = myData.getCol2();
            String parameter3 = myData.getCol3();
            String parameter4 = myData.getCol4();
            String parameter5 = myData.getCol5();

            // Pass parameters into the code as needed
            // Example: print parameters
            System.out.println("Parameters: " + parameter1 + ", " + parameter2 + ", " + parameter3 + ", " + parameter4 + ", " + parameter5);
        }
    }

    // POJO class representing CSV data
    static class MyData {
        private String col1;
        private String col2;
        private String col3;
        private String col4;
        private String col5;

        public MyData(String col1, String col2, String col3, String col4, String col5) {
            this.col1 = col1;
            this.col2 = col2;
            this.col3 = col3;
            this.col4 = col4;
            this.col5 = col5;
        }

        public String getCol1() {
            return col1;
        }

        public String getCol2() {
            return col2;
        }

        public String getCol3() {
            return col3;
        }

        public String getCol4() {
            return col4;
        }

        public String getCol5() {
            return col5;
        }
    }
}