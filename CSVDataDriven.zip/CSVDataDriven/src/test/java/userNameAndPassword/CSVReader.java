package userNameAndPassword;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
    public static void main(String[] args) {
        String csvFile = "C:\\Users\\adith\\OneDrive\\Documents\\UserName.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Process each row of the CSV file
                Person person = convertToPerson(line);
                System.out.println(person);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Person convertToPerson(String line) {
        String[] values = line.split(",");
        int id = Integer.parseInt(values[0]);
        String name = values[1];
        int age = Integer.parseInt(values[2]);

        Person person = new Person();
        person.setId(id);
        person.setName(name);
        person.setAge(age);

        return person;
    }
}