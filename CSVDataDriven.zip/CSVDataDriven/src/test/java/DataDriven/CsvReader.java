import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import lombok.extern.slf4j.Slf4j;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@Slf4j
public class CsvReader {
    public static void main(String[] args) {
        String csvFilePath = "path/to/your/file.csv";

        List<Person> people = readCsvFile(csvFilePath);

        for (Person person : people) {
            // Access parameters from POJO object and pass into the code
            log.info("Name: {}", person.getName());
            log.info("Age: {}", person.getAge());
            log.info("Email: {}", person.getEmail());
            log.info("");
        }
    }

    private static List<Person> readCsvFile(String csvFilePath) {
        List<Person> people = null;

        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            List<String[]> rows = reader.readAll();

            people = CsvToPojoConverter.convert(rows);

        } catch (IOException | CsvException e) {
            log.error("Error reading CSV file", e);
        }

        return people;
    }
}