import java.util.ArrayList;
import java.util.List;

public class CsvToPojoConverter {
    public static List<Person> convert(List<String[]> rows) {
        List<Person> people = new ArrayList<>();

        for (String[] row : rows) {
            // Assuming the order of columns in CSV file is: name, age, email
            Person person = new Person(row[0], Integer.parseInt(row[1]), row[2]);
            people.add(person);
        }

        return people;
    }
}