import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CSV {

    public static void main(String[] args) {
        // Specify the path to your CSV file
        String csvFilePath = "C:\\Users\\adith\\OneDrive\\Documents\\incoming.csv";

        // Reading CSV using Scanner
        

        // Reading CSV using BufferedReader
        readCSVWithBufferedReader(csvFilePath);

        // Converting CSV to POJO classes
        List<MyData> dataList = convertCSVToPOJO(csvFilePath);
        System.out.println("CSV to POJO classes: " + dataList);

        // Converting CSV to ArrayList
        List<String[]> csvArrayList = convertCSVToArrayList(csvFilePath);
        System.out.println("CSV to ArrayList: " + csvArrayList);
    }

    private static void readCSVWithBufferedReader(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Skip header if present
            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                // Process the data as needed
                System.out.println("BufferedReader - Row: " + line + ", Data: " + String.join(", ", data));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<MyData> convertCSVToPOJO(String filePath) {
        List<MyData> dataList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Skip header if present
            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                // Convert CSV data to POJO class
                MyData myData = new MyData(data[0], data[1], data[2], data[3], data[4]);
                dataList.add(myData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataList;
    }

    private static List<String[]> convertCSVToArrayList(String filePath) {
        List<String[]> csvArrayList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Skip header if present
            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                csvArrayList.add(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return csvArrayList;
    }

    // POJO class representing CSV data
    static class MyData {
        private String col1;
        private String col2;
        private String col3;
        private String col4;
        private String col5;

        public MyData(String col1, String col2, String col3, String col4, String col5) {
            this.col1 = col1;
            this.col2 = col2;
            this.col3 = col3;
            this.col4 = col4;
            this.col5 = col5;
        }

        @Override
        public String toString() {
            return "MyData{" +
                    "col1='" + col1 + '\'' +
                    ", col2='" + col2 + '\'' +
                    ", col3='" + col3 + '\'' +
                    ", col4='" + col4 + '\'' +
                    ", col5='" + col5 + '\'' +
                    '}';
        }
    }
}