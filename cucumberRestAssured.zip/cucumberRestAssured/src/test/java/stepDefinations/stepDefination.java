package stepDefinations;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.addPlace;
import pojo.location;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utilities;

public class stepDefination extends Utilities {
	
	RequestSpecification resgiven;
	Response response;
	TestDataBuild  data=new TestDataBuild();
	static String place_Id;
	
	@Given("Add place Payload {string} {string} {string} {string}")
	public void add_place_payload(String name, String phoneNumber, String language, String location) throws IOException {
		resgiven=given().spec(RequestSpecification()).body(data.AddPlacePayload(name, phoneNumber, language, location));
	}
	@When("user calls {string} with {string} http request")
	public void user_calls_with_http_request(String resource, String Method) {
		APIResources resources=APIResources.valueOf(resource);
		System.out.println(resources.getResource());
		
		if(Method.equalsIgnoreCase("POST")) {
			response=resgiven.when().post(resources.getResource())
					.then().spec(ResponseSpecification()).extract().response();
		}
		else if(Method.equalsIgnoreCase("GET")){
			response=resgiven.when().get(resources.getResource())
					.then().spec(ResponseSpecification()).extract().response();
		}
		else if(Method.equalsIgnoreCase("DELETE")){
			response=resgiven.when().delete(resources.getResource())
					.then().spec(ResponseSpecification()).extract().response();
		}
		else if(Method.equalsIgnoreCase("PUT")){
			response=resgiven.when().put(resources.getResource())
					.then().spec(ResponseSpecification()).extract().response();
		}
		
	}
	@Then("the API call is success with status code {int}")
	public void the_api_call_is_success_with_status_code(Integer int1) {
		response.getStatusCode();
	}
	@Then("{string} in response body is {string}")
	public void in_response_body_is(String keyValue, String ExpectedValue) {
		assertEquals(getJsonPath(response, keyValue), ExpectedValue);
	}
	
	@Then("verify Place_Id created maps to {string} using {string}")
	public void verify_place_id_created_maps_to_using(String name, String resource) throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		place_Id=getJsonPath(response, "place_id");
		resgiven=given().spec(RequestSpecification()).queryParam("place_id", place_Id);
		user_calls_with_http_request(resource, "GET");
		String ActualName=getJsonPath(response, "name");
		assertEquals(ActualName, name);
	}
	
	
	@Given("updatePlace Payload")
	public void update_place_payload() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		resgiven=given().spec(RequestSpecification()).body(data.updateplacePayload(place_Id));
	}

	
	@Given("DeletePlace Payload")
	public void delete_place_payload() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		resgiven=given().spec(RequestSpecification()).body(data.deleteplacePayload(place_Id));
	}


}




