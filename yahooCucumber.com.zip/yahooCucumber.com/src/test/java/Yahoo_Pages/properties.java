package Yahoo_Pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class properties {
	
	public WebDriver driver;
	public WebDriver intializeDriver() throws IOException {
		// TODO Auto-generated method stub
		
		Properties prop= new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\prasa\\eclipse-workspace\\yahooCucumber.com\\properties\\data.properties");
		prop.load(file);
		String browser=prop.getProperty("driver");
		if (browser.equals("Chrome")) {
			driver=new ChromeDriver();
		}
		else if(browser.equals("FireFox")) {
			driver=new FirefoxDriver();
		}
		return driver;
		
	}
	
}
