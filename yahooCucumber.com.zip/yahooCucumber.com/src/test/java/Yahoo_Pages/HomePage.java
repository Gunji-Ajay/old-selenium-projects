package Yahoo_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	WebDriver driver;

	public HomePage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public WebElement homebutton() {
		return driver.findElement(By.xpath("//div[@title='Sign In']"));
	}
	
	public WebElement verifySigninPage() {
		return driver.findElement(By.xpath("//span[@class='challenge-desc signin-sub-title']"));
	}
}
