package stepDefinations;

import static org.testng.Assert.assertEquals;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import Yahoo_Pages.HomePage;
import Yahoo_Pages.LoginPage;
import Yahoo_Pages.properties;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class stepDefination {
	properties base= new properties();
	WebDriver driver;

	@Given("user must be in yahoo home page {string}")
	public void user_must_be_in_yahoo_home_page(String string) throws IOException {
		driver= base.intializeDriver();
		driver.get(string);
	}
	
	@Given("move to signin page and assert title {string}")
	public void move_to_signin_page_and_assert_title(String expected) {
	    HomePage signIn=new HomePage(driver);
	    signIn.homebutton().click();
	    String actual=signIn.verifySigninPage().getText();
	    assertEquals(actual, expected);
	}
	
	@When("add credentials username {string} and password {string}")
	public void add_credentials_username_and_password(String username, String password) throws InterruptedException {
		LoginPage login=new LoginPage(driver);
		login.userName().sendKeys(username);
		login.signinclick().click();
		Thread.sleep(3000);
		login.password().sendKeys(password);
		login.signin().click();
		Thread.sleep(3000);

	}
	
	
	@Then("verify the title {string}")
	public void verify_the_title(String string) {
		System.out.println(driver.getTitle());
	}
	
	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}
	
}




