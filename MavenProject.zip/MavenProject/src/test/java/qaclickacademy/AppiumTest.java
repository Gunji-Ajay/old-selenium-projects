package qaclickacademy;

import org.testng.annotations.Test;

public class AppiumTest {
	@Test
	public void AppiumTest1() {
		System.out.println("AppiumTest1");
	}
	
	@Test
	public void AppiumTest2() {
		System.out.println("AppiumTest2");
	}
}
