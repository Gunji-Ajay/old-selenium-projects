package seleniumJunit;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class sample {
	@Test
	public void testng() throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver=new FirefoxDriver();
		driver.get("https://blazedemo.com/");
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.quit();
		
	}

}
