package restapi;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;
import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;


import SerializationObj.addPlace;
import SerializationObj.location;
import base.json;

public class serialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addPlace p = new addPlace();
		p.setAccuracy(50);
		p.setName("Prasanth Kovvela");
		p.setPhone_number("9553377308");
		p.setAddress("near high school, main road, Magam");
		p.setWebsite("https://rahulshettyacademy.com");
		p.setLanguage("French-IN");
		
		List<String> mylist =new ArrayList<String>();
		mylist.add("shoe park");
		mylist.add("shop");
		p.setTypes(mylist);
		
		location l=new location();
		
		l.setLat(-38.383494);
		l.setLng(33.427362);
		p.setLocation(l);
		
			
		RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
									.addQueryParam("key", "qaclick123").setContentType(ContentType.JSON).build();
		
		
		ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
		
		RequestSpecification resgiven=given().spec(req).body(p);
		
		Response response=resgiven.when().post("/maps/api/place/add/json")
		.then().spec(res).log().all().extract().response();
		
		
		
		assertEquals(response.getStatusCode(), 200);
		
		String result=response.asString();
		JsonPath js=new JsonPath(result);
		String result1=js.getString("place_id");
		
		
		System.out.println(result1);
	
		
		
		
		
		
		
		

	}

}
