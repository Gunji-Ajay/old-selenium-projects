package restapi;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BodyForPost;
import base.json;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class AddBook {
	
	@Test (dataProvider="getdata")
	public void getBook(String fir, String sec) {
		RestAssured.baseURI="http://216.10.245.166";
		String response=given().log().all().header("Content-Type", "application/json").body(BodyForPost.addBook(fir, sec)).when().post("Library/Addbook.php").
		then().assertThat().log().all().statusCode(200).extract().response().asString();
		
		JsonPath js=json.convertJson(response);
		String res=js.getString("ID");
		System.out.println(res);
	}
	
	@DataProvider
	public Object[][] getdata() {
		Object[][] data=new Object[1][2];
		data[0][0]="Prasanth";
		data[0][1]="Kovvela";
		return data;
	}

}
