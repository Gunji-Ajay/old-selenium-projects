package restapi;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BodyForPost;
import base.json;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DynamicJson {
	
	@Test (dataProvider="getdata")
	public void addBook(String omn, String tw) throws IOException {
		RestAssured.baseURI="http://216.10.245.166";
		String Response=given().log().all().header("Content-Type", "application/json").
		body(new String(Files.readAllBytes(Paths.get("D:\\persistent\\restApi.json")))).when().post("Library/Addbook.php").then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
		JsonPath js=json.convertJson(Response);
		String id=js.getString("ID");
		System.out.println(id);
	}
	
	
	@DataProvider
	public Object[][] getdata() {
		return new Object[][] {{"prasa", "nth"}, {"kovv", "ela"}, {"bhava", "na"}};
	}

}
