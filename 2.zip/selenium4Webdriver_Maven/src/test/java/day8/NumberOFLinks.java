package day8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NumberOFLinks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			WebDriver driver=new FirefoxDriver();
			driver.get("https://www.google.co.in");
	        List<WebElement> numberOfLinks = driver.findElements(By.tagName("a"));
	        // count no of links on page
	        System.out.println(numberOfLinks);
	        System.out.println(numberOfLinks.size());

	}

}
