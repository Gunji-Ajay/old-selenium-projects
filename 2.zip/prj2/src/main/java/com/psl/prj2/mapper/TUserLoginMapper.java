package com.psl.prj2.mapper;

import com.psl.prj2.entity.TUserLogin;
import com.psl.prj2.entity.TUserLoginExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.type.JdbcType;

public interface TUserLoginMapper {
    @SelectProvider(type=TUserLoginSqlProvider.class, method="countByExample")
    long countByExample(TUserLoginExample example);

    @DeleteProvider(type=TUserLoginSqlProvider.class, method="deleteByExample")
    int deleteByExample(TUserLoginExample example);

    @Delete({
        "delete from t_user_login",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into t_user_login (id, userId, ",
        "deviceId, loginCredential, ",
        "createTime, logOutTime, ",
        "inValidateTime, status)",
        "values (#{id,jdbcType=INTEGER}, #{userid,jdbcType=INTEGER}, ",
        "#{deviceid,jdbcType=CHAR}, #{logincredential,jdbcType=CHAR}, ",
        "#{createtime,jdbcType=CHAR}, #{logouttime,jdbcType=CHAR}, ",
        "#{invalidatetime,jdbcType=CHAR}, #{status,jdbcType=CHAR})"
    })
    int insert(TUserLogin record);

    @InsertProvider(type=TUserLoginSqlProvider.class, method="insertSelective")
    int insertSelective(TUserLogin record);

    @SelectProvider(type=TUserLoginSqlProvider.class, method="selectByExample")
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="userId", property="userid", jdbcType=JdbcType.INTEGER),
        @Result(column="deviceId", property="deviceid", jdbcType=JdbcType.CHAR),
        @Result(column="loginCredential", property="logincredential", jdbcType=JdbcType.CHAR),
        @Result(column="createTime", property="createtime", jdbcType=JdbcType.CHAR),
        @Result(column="logOutTime", property="logouttime", jdbcType=JdbcType.CHAR),
        @Result(column="inValidateTime", property="invalidatetime", jdbcType=JdbcType.CHAR),
        @Result(column="status", property="status", jdbcType=JdbcType.CHAR)
    })
    List<TUserLogin> selectByExampleWithRowbounds(TUserLoginExample example, RowBounds rowBounds);

    @SelectProvider(type=TUserLoginSqlProvider.class, method="selectByExample")
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="userId", property="userid", jdbcType=JdbcType.INTEGER),
        @Result(column="deviceId", property="deviceid", jdbcType=JdbcType.CHAR),
        @Result(column="loginCredential", property="logincredential", jdbcType=JdbcType.CHAR),
        @Result(column="createTime", property="createtime", jdbcType=JdbcType.CHAR),
        @Result(column="logOutTime", property="logouttime", jdbcType=JdbcType.CHAR),
        @Result(column="inValidateTime", property="invalidatetime", jdbcType=JdbcType.CHAR),
        @Result(column="status", property="status", jdbcType=JdbcType.CHAR)
    })
    List<TUserLogin> selectByExample(TUserLoginExample example);

    @Select({
        "select",
        "id, userId, deviceId, loginCredential, createTime, logOutTime, inValidateTime, ",
        "status",
        "from t_user_login",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="userId", property="userid", jdbcType=JdbcType.INTEGER),
        @Result(column="deviceId", property="deviceid", jdbcType=JdbcType.CHAR),
        @Result(column="loginCredential", property="logincredential", jdbcType=JdbcType.CHAR),
        @Result(column="createTime", property="createtime", jdbcType=JdbcType.CHAR),
        @Result(column="logOutTime", property="logouttime", jdbcType=JdbcType.CHAR),
        @Result(column="inValidateTime", property="invalidatetime", jdbcType=JdbcType.CHAR),
        @Result(column="status", property="status", jdbcType=JdbcType.CHAR)
    })
    TUserLogin selectByPrimaryKey(Integer id);

    @UpdateProvider(type=TUserLoginSqlProvider.class, method="updateByExampleSelective")
    int updateByExampleSelective(@Param("record") TUserLogin record, @Param("example") TUserLoginExample example);

    @UpdateProvider(type=TUserLoginSqlProvider.class, method="updateByExample")
    int updateByExample(@Param("record") TUserLogin record, @Param("example") TUserLoginExample example);

    @UpdateProvider(type=TUserLoginSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(TUserLogin record);

    @Update({
        "update t_user_login",
        "set userId = #{userid,jdbcType=INTEGER},",
          "deviceId = #{deviceid,jdbcType=CHAR},",
          "loginCredential = #{logincredential,jdbcType=CHAR},",
          "createTime = #{createtime,jdbcType=CHAR},",
          "logOutTime = #{logouttime,jdbcType=CHAR},",
          "inValidateTime = #{invalidatetime,jdbcType=CHAR},",
          "status = #{status,jdbcType=CHAR}",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(TUserLogin record);
}