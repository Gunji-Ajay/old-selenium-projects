package com.psl.prj2.entity;

import java.io.Serializable;

public class TUserLogin implements Serializable {
    private Integer id;

    private Integer userid;

    private String deviceid;

    private String logincredential;

    private String createtime;

    private String logouttime;

    private String invalidatetime;

    private String status;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid == null ? null : deviceid.trim();
    }

    public String getLogincredential() {
        return logincredential;
    }

    public void setLogincredential(String logincredential) {
        this.logincredential = logincredential == null ? null : logincredential.trim();
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public String getLogouttime() {
        return logouttime;
    }

    public void setLogouttime(String logouttime) {
        this.logouttime = logouttime == null ? null : logouttime.trim();
    }

    public String getInvalidatetime() {
        return invalidatetime;
    }

    public void setInvalidatetime(String invalidatetime) {
        this.invalidatetime = invalidatetime == null ? null : invalidatetime.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }
}