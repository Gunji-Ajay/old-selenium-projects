package com.psl.prj2.mapper;

import com.psl.prj2.entity.TUser;
import org.apache.ibatis.jdbc.SQL;

public class TUserSqlProvider {
    public String insertSelective(TUser record) {
        SQL sql = new SQL();
        sql.INSERT_INTO("t_user");
        
        if (record.getId() != null) {
            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
        }
        
        if (record.getLoginname() != null) {
            sql.VALUES("loginName", "#{loginname,jdbcType=VARCHAR}");
        }
        
        if (record.getLoginpwd() != null) {
            sql.VALUES("loginPwd", "#{loginpwd,jdbcType=CHAR}");
        }
        
        if (record.getMobileno() != null) {
            sql.VALUES("mobileNo", "#{mobileno,jdbcType=VARCHAR}");
        }
        
        if (record.getNickname() != null) {
            sql.VALUES("nickName", "#{nickname,jdbcType=VARCHAR}");
        }
        
        if (record.getSex() != null) {
            sql.VALUES("sex", "#{sex,jdbcType=SMALLINT}");
        }
        
        if (record.getEmail() != null) {
            sql.VALUES("email", "#{email,jdbcType=CHAR}");
        }
        
        if (record.getCreatetime() != null) {
            sql.VALUES("createTime", "#{createtime,jdbcType=TIMESTAMP}");
        }
        
        if (record.getLastmodifytime() != null) {
            sql.VALUES("lastModifyTime", "#{lastmodifytime,jdbcType=TIMESTAMP}");
        }
        
        if (record.getLastlogintime() != null) {
            sql.VALUES("lastLoginTime", "#{lastlogintime,jdbcType=CHAR}");
        }
        
        if (record.getLoginerrcount() != null) {
            sql.VALUES("loginErrCount", "#{loginerrcount,jdbcType=SMALLINT}");
        }
        
        if (record.getLastrecordloginerrtime() != null) {
            sql.VALUES("lastRecordLoginErrTime", "#{lastrecordloginerrtime,jdbcType=CHAR}");
        }
        
        if (record.getStatus() != null) {
            sql.VALUES("status", "#{status,jdbcType=CHAR}");
        }
        
        return sql.toString();
    }

    public String updateByPrimaryKeySelective(TUser record) {
        SQL sql = new SQL();
        sql.UPDATE("t_user");
        
        if (record.getLoginname() != null) {
            sql.SET("loginName = #{loginname,jdbcType=VARCHAR}");
        }
        
        if (record.getLoginpwd() != null) {
            sql.SET("loginPwd = #{loginpwd,jdbcType=CHAR}");
        }
        
        if (record.getMobileno() != null) {
            sql.SET("mobileNo = #{mobileno,jdbcType=VARCHAR}");
        }
        
        if (record.getNickname() != null) {
            sql.SET("nickName = #{nickname,jdbcType=VARCHAR}");
        }
        
        if (record.getSex() != null) {
            sql.SET("sex = #{sex,jdbcType=SMALLINT}");
        }
        
        if (record.getEmail() != null) {
            sql.SET("email = #{email,jdbcType=CHAR}");
        }
        
        if (record.getCreatetime() != null) {
            sql.SET("createTime = #{createtime,jdbcType=TIMESTAMP}");
        }
        
        if (record.getLastmodifytime() != null) {
            sql.SET("lastModifyTime = #{lastmodifytime,jdbcType=TIMESTAMP}");
        }
        
        if (record.getLastlogintime() != null) {
            sql.SET("lastLoginTime = #{lastlogintime,jdbcType=CHAR}");
        }
        
        if (record.getLoginerrcount() != null) {
            sql.SET("loginErrCount = #{loginerrcount,jdbcType=SMALLINT}");
        }
        
        if (record.getLastrecordloginerrtime() != null) {
            sql.SET("lastRecordLoginErrTime = #{lastrecordloginerrtime,jdbcType=CHAR}");
        }
        
        if (record.getStatus() != null) {
            sql.SET("status = #{status,jdbcType=CHAR}");
        }
        
        sql.WHERE("id = #{id,jdbcType=INTEGER}");
        
        return sql.toString();
    }
}