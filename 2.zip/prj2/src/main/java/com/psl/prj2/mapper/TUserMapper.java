package com.psl.prj2.mapper;

import com.psl.prj2.entity.TUser;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface TUserMapper {
    @Delete({
        "delete from t_user",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into t_user (id, loginName, ",
        "loginPwd, mobileNo, ",
        "nickName, sex, ",
        "email, createTime, ",
        "lastModifyTime, lastLoginTime, ",
        "loginErrCount, lastRecordLoginErrTime, ",
        "status)",
        "values (#{id,jdbcType=INTEGER}, #{loginname,jdbcType=VARCHAR}, ",
        "#{loginpwd,jdbcType=CHAR}, #{mobileno,jdbcType=VARCHAR}, ",
        "#{nickname,jdbcType=VARCHAR}, #{sex,jdbcType=SMALLINT}, ",
        "#{email,jdbcType=CHAR}, #{createtime,jdbcType=TIMESTAMP}, ",
        "#{lastmodifytime,jdbcType=TIMESTAMP}, #{lastlogintime,jdbcType=CHAR}, ",
        "#{loginerrcount,jdbcType=SMALLINT}, #{lastrecordloginerrtime,jdbcType=CHAR}, ",
        "#{status,jdbcType=CHAR})"
    })
    int insert(TUser record);

    @InsertProvider(type=TUserSqlProvider.class, method="insertSelective")
    int insertSelective(TUser record);

    @Select({
        "select",
        "id, loginName, loginPwd, mobileNo, nickName, sex, email, createTime, lastModifyTime, ",
        "lastLoginTime, loginErrCount, lastRecordLoginErrTime, status",
        "from t_user",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="loginName", property="loginname", jdbcType=JdbcType.VARCHAR),
        @Result(column="loginPwd", property="loginpwd", jdbcType=JdbcType.CHAR),
        @Result(column="mobileNo", property="mobileno", jdbcType=JdbcType.VARCHAR),
        @Result(column="nickName", property="nickname", jdbcType=JdbcType.VARCHAR),
        @Result(column="sex", property="sex", jdbcType=JdbcType.SMALLINT),
        @Result(column="email", property="email", jdbcType=JdbcType.CHAR),
        @Result(column="createTime", property="createtime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="lastModifyTime", property="lastmodifytime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="lastLoginTime", property="lastlogintime", jdbcType=JdbcType.CHAR),
        @Result(column="loginErrCount", property="loginerrcount", jdbcType=JdbcType.SMALLINT),
        @Result(column="lastRecordLoginErrTime", property="lastrecordloginerrtime", jdbcType=JdbcType.CHAR),
        @Result(column="status", property="status", jdbcType=JdbcType.CHAR)
    })
    TUser selectByPrimaryKey(Integer id);

    @UpdateProvider(type=TUserSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(TUser record);

    @Update({
        "update t_user",
        "set loginName = #{loginname,jdbcType=VARCHAR},",
          "loginPwd = #{loginpwd,jdbcType=CHAR},",
          "mobileNo = #{mobileno,jdbcType=VARCHAR},",
          "nickName = #{nickname,jdbcType=VARCHAR},",
          "sex = #{sex,jdbcType=SMALLINT},",
          "email = #{email,jdbcType=CHAR},",
          "createTime = #{createtime,jdbcType=TIMESTAMP},",
          "lastModifyTime = #{lastmodifytime,jdbcType=TIMESTAMP},",
          "lastLoginTime = #{lastlogintime,jdbcType=CHAR},",
          "loginErrCount = #{loginerrcount,jdbcType=SMALLINT},",
          "lastRecordLoginErrTime = #{lastrecordloginerrtime,jdbcType=CHAR},",
          "status = #{status,jdbcType=CHAR}",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(TUser record);
}