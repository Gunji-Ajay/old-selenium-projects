package log4J;

import org.apache.logging.log4j.*;
public class trail1 {
	private static Logger log=LogManager.getLogger(trail1.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		log.debug("i am debugging");
		log.error("i am error");
		log.fatal("this is fatel");
		log.info("im the info");
	}

}
