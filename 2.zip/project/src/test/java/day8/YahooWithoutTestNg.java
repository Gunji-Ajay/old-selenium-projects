package day8;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class YahooWithoutTestNg {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		File src=new File("src/test/java/Input/yahoo.xlsx");
		FileInputStream fileInput=new FileInputStream(src);
		Workbook wb = new XSSFWorkbook(fileInput);   
		XSSFSheet sheet1 = (XSSFSheet) wb.getSheetAt(0);

		WebDriver driver=new ChromeDriver();
		driver.get("https://in.search.yahoo.com/?fr2=inr");
		
		double playerNo = sheet1.getRow(1).getCell(0).getNumericCellValue();
		String userName = sheet1.getRow(1).getCell(1).getStringCellValue();
		String pass = sheet1.getRow(1).getCell(2).getStringCellValue();
		String toMail = sheet1.getRow(1).getCell(3).getStringCellValue();
		String Subject = sheet1.getRow(1).getCell(4).getStringCellValue();
		String Message = sheet1.getRow(1).getCell(5).getStringCellValue();
		
		driver.findElement(By.xpath("//div[@class='text' and @title='Sign In']")).click();
		driver.findElement(By.id("login-username")).sendKeys(userName);
		driver.findElement(By.id("login-signin")).click();
	    Thread.sleep(2000);
		driver.findElement(By.id("login-passwd")).sendKeys(pass);
		driver.findElement(By.id("login-signin")).click();		
		driver.findElement(By.cssSelector("div[title='Mail']")).click();
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("a[role='button']")).click();
		driver.findElement(By.cssSelector("input[aria-owns='react-typehead-list-to']")).sendKeys(toMail);
		driver.findElement(By.cssSelector("input[data-test-id='compose-subject']")).sendKeys(Subject);
		driver.findElement(By.cssSelector("div[data-test-id='rte']")).sendKeys(Message);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[title='Send this email']")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("span[ data-test-folder-name='Sent']")).click();
		Thread.sleep(2000);
		
		
		TakesScreenshot ss=(TakesScreenshot)driver;
		File Imgfile=ss.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Imgfile, new File("./Screenshots/Image1.png"));
		Thread.sleep(2000);
		
		driver.findElement(By.id("ybar-logo")).click();
		Thread.sleep(2000);
		Actions mouseActions=new Actions(driver);
		mouseActions.moveToElement(driver.findElement(By.cssSelector("label[id='ybarAccountMenuOpener']"))).perform();
		Thread.sleep(2000);
		mouseActions.moveToElement(driver.findElement(By.id("profile-signout-link"))).click().perform();
		Thread.sleep(2000);
		driver.quit();
		
	}

}
