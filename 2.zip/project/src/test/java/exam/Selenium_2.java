package exam;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert.*;

public class Selenium_2 {
    private WebDriver driver;
    public static String baseUrl="http://app.e-box.co.in/uploads/weddingc.html";
    public static Boolean h2Present;
	public static String h2ElementText;


	@BeforeTest
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}


	@Test
	public void testWeb() throws Exception {

		h2Present=driver.findElement(By.tagName("h2")).isDisplayed();
		h2ElementText=driver.findElement(By.tagName("h2")).getText();
		//Fill your code here
		
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
		
	}
}