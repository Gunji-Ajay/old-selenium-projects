package exam;

import java.util.concurrent.TimeUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert.*;
import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_1 {
  public static WebDriver driver;
  public static String baseUrl="https://app.e-box.co.in/uploads/base_projects/20991_index.html";
  public static boolean isLearningPresent = false;
  public static boolean isAssessmentPresent = false;
  public static String learningClass1,learningClass2,learningClass3,learningClass4;
  public static String assessmentClass1,assessmentClass2,assessmentClass3,assessmentClass4;
  public static int rowSize, colSize1,colSize3,colSize2,colSize4;
  
  @BeforeTest
  public void setUp() throws Exception {
        driver = new FirefoxDriver();
	driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
  }

  @Test
  public void testWeb() throws Exception {
        driver.get(baseUrl);
        isLearningPresent=driver.findElement(By.id("learning")).isDisplayed();
        learningClass1=driver.findElement(By.xpath("//a[@id='learning']/span")).getAttribute("class");
        isAssessmentPresent=driver.findElement(By.xpath("//a[@id='assessment']")).isDisplayed();
        assessmentClass1=driver.findElement(By.xpath("//a[@id='assessment']/span")).getAttribute("class");
		rowSize=driver.findElements(By.tagName("tr")).size();
		colSize1=driver.findElements(By.tagName("th")).size();
        		      
  }

  @AfterTest
  public void tearDown() throws Exception {
	driver.quit();
  }
  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }
}