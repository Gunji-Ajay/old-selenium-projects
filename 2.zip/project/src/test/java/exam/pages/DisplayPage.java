package exam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class DisplayPage {
	
	WebDriver driver;
	public DisplayPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}
	
	@FindBy(tagName = "h1")
	WebElement tagElement;
	public String getH1tag()
	
	{
		tagElement.isDisplayed();
	 return	tagElement.getText();
	}
	
	@FindBy(id="userDetailTable")
	WebElement userDetails;
	public String getResult()
	{
		return	userDetails.getText();
	}
	//fill your code
}


