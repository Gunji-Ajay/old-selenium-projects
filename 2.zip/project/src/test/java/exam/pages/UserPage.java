package exam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserPage {

	WebDriver driver;
	//fill your code
	public UserPage(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(name="name")
	WebElement nameElement;
	public void setName(String name)
	{
		nameElement.sendKeys(name);
	}
	
	@FindBy(name="email")
	WebElement emailElement;
	public void setEmail(String email)
	{
		emailElement.sendKeys(email);
	}
	
	@FindBy(name="password")
	WebElement passwordElement;
	public void setPassword(String password)
	{
		passwordElement.sendKeys(password);
	}

	@FindBy(name="age")
	WebElement ageElement;
	public void setAge(String age)
	{
		ageElement.sendKeys(age);
	}
	
	@FindBy(name="role")
	WebElement roleElement;
	public void setRole(String role)
	{
		roleElement.sendKeys(role);
	}
	
	@FindBy(name="submit")
	WebElement submitElement;
	public void clickSubmit()
	{
		submitElement.click();
	}
	
}
