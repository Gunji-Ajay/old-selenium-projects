package exam;

import java.util.concurrent.TimeUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class mock_exam {
    private WebDriver driver;
    public static String baseUrl="http://app.e-box.co.in/uploads/EventsTable.html";
    private StringBuffer verificationErrors = new StringBuffer();
	public static Boolean h2Present;
	public static String h2ElementText,headerTxt,tableDataTxt1,tableDataTxt2;


	@BeforeTest
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}


	@Test
	public void testWeb() throws Exception {
        
		driver.get(baseUrl);
		
		h2Present=driver.findElement(By.tagName("h2")).isDisplayed();
		h2ElementText=driver.findElement(By.tagName("h2")).getText();				
		headerTxt=driver.findElement(By.xpath("//th[contains(text(),'Start Time')]")).getText();
		tableDataTxt1=driver.findElement(By.xpath("//td[contains(text(),'Vivekanandha Auditorium')]")).getText();
		tableDataTxt2=driver.findElement(By.xpath("//td[contains(text(),'11.11.2018 5.00')]")).getText();
		
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
		
	}

}