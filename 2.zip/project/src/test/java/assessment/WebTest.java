package assessment;

import java.util.concurrent.TimeUnit;
import org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTest {
    private WebDriver driver;
    public static String baseUrl="http://app.e-box.co.in/uploads/base_projects/21004_index.html";
	public static boolean h1Tag,userName,passWord;
	public static String h1Element,nameTxt,genderTxt,eventTxt,result;

	@BeforeTest
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWeb() throws Exception {
        
		driver.get(baseUrl);
        
        	//Fill your code here
    	//Fill your code here
		h1Tag=driver.findElement(By.tagName("h1")).isDisplayed();
		h1Element=driver.findElement(By.tagName("h1")).getText();
		nameTxt=driver.findElement(By.tagName("td")).getText();
		userName=driver.findElement(By.xpath("//input[@name='userName']")).isDisplayed();
		passWord=driver.findElement(By.xpath("//input[@name='password']")).isDisplayed();

		driver.findElement(By.name("name")).sendKeys("MayaSri");
		driver.findElement(By.name("userName")).sendKeys("Maya");
		driver.findElement(By.name("password")).sendKeys(" Maya123");
		driver.findElement(By.name("re-EnterPassword")).sendKeys("Maya123");
		driver.findElement(By.name("address")).sendKeys("155th Avenue, London");
		driver.findElement(By.xpath("//input[@name='gender' and @value='female']")).click();
		driver.findElement(By.xpath("//select/option[@value='coimbatore']")).click();
		driver.findElement(By.xpath("//input[@value='wedding']")).click();
		driver.findElement(By.name("register")).click();

		genderTxt=driver.findElement(By.xpath("//input[@name='gender'][2]")).getAttribute("value");
		eventTxt=driver.findElement(By.name("events[]")).getAttribute("value");

		driver.findElement(By.xpath("//div[@id='result']")).isDisplayed();
		result=driver.findElement(By.xpath("//div[@id='result']")).getText();
			

    
	}

	@AfterTest
	public void tearDown() throws Exception {
		//driver.quit();
		Thread.sleep(2000);
	}

}