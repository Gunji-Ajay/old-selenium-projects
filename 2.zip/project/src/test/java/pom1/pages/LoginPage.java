package pom1.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPage {
	private WebElement username;
	private WebElement password;
	private WebElement signin;
	private WebDriver driver;
	private String baseUrl;
	
	public LoginPage()
	{
		//baseUrl = "https://login.yahoo.com/";
		driver = new ChromeDriver();
		driver.get("https://login.yahoo.com/");
	}
	
	public void login(String user, String pwd) throws InterruptedException
	{
		username = driver.findElement(By.id("login-username"));
		username.sendKeys(user);
		signin = driver.findElement(By.id("login-signin"));
		signin.click();
		
		Thread.sleep(4000);
		
		password = driver.findElement(By.id("login-passwd"));
		password.sendKeys(pwd);
		signin = driver.findElement(By.id("login-signin"));
		signin.click();
		Thread.sleep(4000);

		System.out.println("you have successfully loged in to "+user);
	}
	
	public String getPageTitleAfterLogin()
	{
		return driver.getTitle();
	}
	
	public void closeBrowser()
	{
		driver.quit();
	}
	
}
