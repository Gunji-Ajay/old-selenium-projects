package pom1.tests;

import org.testng.annotations.Test;
import pom1.pages.LoginPage;
import org.testng.annotations.BeforeMethod;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.AfterMethod;
	

public class LoginPageTest {
	LoginPage myLoginPage;
	
	
  @Test
  public void loginTest() throws InterruptedException {
	  myLoginPage.login("prasanthkovvela1", "8096149628.K");
	  String expectedTitle = "Yahoo Search - Web Search";
	  String actualTitle = myLoginPage.getPageTitleAfterLogin();
	  assertEquals(actualTitle, expectedTitle);
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
	  myLoginPage = new LoginPage();
  }

  @AfterMethod
  public void afterMethod() {
	  myLoginPage.closeBrowser();
  }

}
