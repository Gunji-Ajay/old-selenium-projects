package pom1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class YahooMailLogin {
	WebDriver driver;
	
  @Test
  public void selectDropDown() throws InterruptedException, IOException {
	  
	  String baseUrl = "https://login.yahoo.com/";
	  String email = "prasanthkovvela1";
	  String password = "8096149628.K";
	  
	  driver.get(baseUrl);
//	  System.out.println("Page Title" + driver.getTitle());
	  
	  driver.findElement(By.id("login-username")).sendKeys(email);
	  driver.findElement(By.id("login-signin")).click();
	  Thread.sleep(4000);
	  driver.findElement(By.id("login-passwd")).sendKeys(password);
	  driver.findElement(By.id("login-signin")).click();
  }
  
  @BeforeClass
  public void beforeClass() {
	  driver  = new ChromeDriver();
  }

  @AfterClass
  public void afterClass() throws InterruptedException {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
