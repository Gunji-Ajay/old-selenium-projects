package day5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class TestNg_basics {
	WebDriver driver;
	@Test
  public void f() throws InterruptedException {
		driver.get("http://google.com");
		Thread.sleep(3000);
		String ActualTitle=driver.getTitle();
		String Title="Google";
		assertEquals(ActualTitle, Title);
  }
  @BeforeMethod
  public void beforeMethod() {
	  driver=new ChromeDriver();
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
