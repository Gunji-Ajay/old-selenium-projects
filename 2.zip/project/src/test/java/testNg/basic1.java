package testNg;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class basic1 {
	
	@Test
	public static  void greeting() {
		// TODO Auto-generated method stub
		System.out.println("helloooo for Basic1");
		
	}
	@Parameters({"prasanth1url", "prasanth1pass"})
	@Test
	public static  void subject(String url, String pass) {
		// TODO Auto-generated method stub
		System.out.println("New to testNg for Basic1");
		System.out.println("prasanth's url is: "+url+ " for Basic1");
		System.out.println("prasanth's password is: "+pass+ " for Basic1");
	}
	
}
