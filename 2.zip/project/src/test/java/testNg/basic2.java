package testNg;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class basic2 {
	
	@Test
	public static void main() {
		// TODO Auto-generated method stub
		System.out.println("practice for Basic2");
	}
	
	@Test(enabled= false)
	public static void enable() {
		// TODO Auto-generated method stub
		System.out.println("test is to skip for Basic2");
	}
	
	@Test
	public static void timeout() {
		// TODO Auto-generated method stub
		System.out.println("test is wait untill time instead of throwing error for Basic2");
		//Assert.assertTrue(false);
	}
	
	@AfterSuite
	public static  void Beforesuite() {
		// TODO Auto-generated method stub
		System.out.println("AfterSuite for basic2");
	}
	
	@BeforeSuite
	public static  void Aftersubject() {
		// TODO Auto-generated method stub
		System.out.println("BeforeSuite for basic2");
	}
}
