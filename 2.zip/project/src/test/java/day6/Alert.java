package day6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.findElement(By.xpath("//a[@href='#OKTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-danger'][contains(text(), 'alert box')]")).click();
		Thread.sleep(2000);
		org.openqa.selenium.Alert alertOk=driver.switchTo().alert();
		alertOk.accept();
		Thread.sleep(1000);
		
		
		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Thread.sleep(2000);
		org.openqa.selenium.Alert alertOkCancel=driver.switchTo().alert();
		alertOkCancel.accept();
		System.out.println(driver.findElement(By.id("demo")).getText());
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Thread.sleep(2000);
		org.openqa.selenium.Alert alertTextbox=driver.switchTo().alert();
		alertTextbox.accept();
		System.out.println(driver.findElement(By.id("demo1")).getText());
		Thread.sleep(1000);
	}
}
