package day6;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class windowsHandle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		
		driver.findElement(By.id("openwindow")).click();
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		
		Set<String>uniqueIds=driver.getWindowHandles();
		System.out.println("ID's of all open windows:- "+uniqueIds);
		
		java.util.Iterator<String> it=uniqueIds.iterator();
		String parentId=it.next();
		String childId=it.next();
		driver.switchTo().window(childId);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		String title=driver.getTitle();
		
		if (title.equals("QA Click Academy | Selenium,Jmeter,SoapUI,Appium,Database testing,QA Training Academy")) {
			System.out.println("switched to child window successfully");
			System.out.println("Title of the child window is:- "+title);
			Actions mouseActions=new Actions(driver);
			mouseActions.moveToElement(driver.findElement(By.xpath("//a[text()='Home']"))).click().perform();
			Thread.sleep(2000);
			
			mouseActions.moveToElement(driver.findElement(By.xpath("//a[@class='dropdown-toggle' and text()='More ']"))).perform();
			mouseActions.moveToElement(driver.findElement(By.xpath("//a[@href='#/about-my-mission'][1]"))).click().perform();
			
			JavascriptExecutor scroll=(JavascriptExecutor) driver;
			scroll.executeScript("window.scrollBy(0, 180)");
			Thread.sleep(8000);
			scroll.executeScript("window.scrollBy(0, 500)");
			Thread.sleep(8000);
			
			driver.switchTo().window(parentId);
			System.out.println("switched to parent window successfully");
			System.out.println("Title of the parent window is:- "+driver.getTitle());
			Thread.sleep(3000);
			driver.quit();
		
		}
		else
			System.out.println("not switched to new window");
	}

}
