package day6;

import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class windows {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://appost.in/gdsonline/Home.aspx");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//a[@href='FAQ.html' and text()='FAQ']")).click();
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		
		Set<String>uniqueIds=driver.getWindowHandles();
		System.out.println(uniqueIds);
		
		java.util.Iterator<String> it=uniqueIds.iterator();
		String parentId=it.next();
		String childId=it.next();
		driver.switchTo().window(childId);
		Thread.sleep(2000);
		
		String hint=driver.getTitle();
		System.out.println(hint);
		if (hint.equals("FAQ")) {
			System.out.println("switched to new tab successfully");
			driver.findElement(By.xpath("//li/a[@href='#mobile']")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[contains(text(), 'Fee Payable')]")).click();
			Thread.sleep(5000);
			
			System.out.println(driver.findElement(By.xpath("//*[contains(text(), 'Fee Payable')]")).getText());
			System.out.println(driver.findElement(By.xpath("//ul/li/descendant::p[contains(text(), 'OBC/General')]")).getText());
			
			
			driver.switchTo().window(parentId);
			System.out.println(driver.getTitle());
			Thread.sleep(3000);
			driver.quit();
			
		}
		else
			System.out.println("not switched to new tab");
	}

}
