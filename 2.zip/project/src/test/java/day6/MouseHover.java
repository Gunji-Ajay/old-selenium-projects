package day6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHover {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Alerts.html");
		
		
		Actions mouseActions=new Actions(driver);
		mouseActions.moveToElement(driver.findElement(By.xpath("//a[@href='SwitchTo.html' and text()='Video']"))).perform();
		mouseActions.moveToElement(driver.findElement(By.xpath("//a[@href='Youtube.html' and text()='Youtube']"))).click().perform();
		//a[@href='Youtube.html' and text()='Youtube']
		
		
		
		
	}
}
