package newfeatures;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class basics {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
			
		WebDriver driver=new ChromeDriver();
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		System.out.println("page is successfully opened");
		WebElement wb=driver.findElement(By.cssSelector("input[name=airbags]"));
		driver.findElement(with(By.tagName("input")).above(wb)).click();
		driver.findElement(with(By.tagName("input")).below(wb)).click();
		
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));	
	}
}
