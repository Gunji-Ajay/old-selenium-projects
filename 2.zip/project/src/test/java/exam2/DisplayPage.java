package exam2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DisplayPage {
	
	WebDriver driver;
	public DisplayPage(WebDriver driver)
	{
		this.driver=driver;
	}
	@FindBy(tagName ="h2")
	WebElement h2Tag;
	
	@FindBy(xpath ="//div[@id='result']/br")
	WebElement message;
	
	public String getH2tag()
	{
	  return h2Tag.getText();
	}
	public String getMessage()
	{
	  return message.getText();
	}
}