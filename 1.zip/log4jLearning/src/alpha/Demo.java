package alpha;

import org.apache.logging.log4j.*;

public class Demo {
	private static Logger log=LogManager.getLogger(Demo.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		log.debug("i am debugging");
		log.error("i am error");
		log.fatal("this is fatel");
		log.info("im the info");
	}

}
