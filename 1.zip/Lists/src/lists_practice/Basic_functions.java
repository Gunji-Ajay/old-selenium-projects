package lists_practice;
import java.util.ArrayList;
public class Basic_functions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list=new ArrayList<Integer>();
		System.out.println(list);
		System.out.println("size of the list is: "+list.size());
		
		list.add(10);
		list.add(new Integer(50));
		System.out.println(list);
		System.out.println("size of the list is: "+list.size());
		
		list.add(1, 90);
		list.add(31);
		System.out.println(list);
		System.out.println("size of the list is: "+list.size());
		
		list.remove(2);
		System.out.println(list);
		System.out.println("size of the list is: "+list.size());
		
		boolean iscontain= list.contains(31);
			if (iscontain)
				System.out.println("Ok");
			else 
				System.out.println("Not Ok");
			
			int sum=0;
			for(int i=0; i<list.size(); i++) {
				sum+=list.get(i);
			}
			System.out.println(sum);
			list.clear();
			System.out.print(list);
		
	}
}


