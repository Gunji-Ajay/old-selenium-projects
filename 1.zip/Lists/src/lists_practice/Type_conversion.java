package lists_practice;
import java.util.ArrayList;
public class Type_conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] itemsNeeded= {"Cucumber","Brocolli","Cauliflower","Beatroot",
                "Carrot","Tomato","Beans","Brinjal","Capsicum","Mushroom","Potato",
                "Pumkin","Corn","Onion","Apple","Banana","Grapes","Mango",
                "Musk Melon","Orange","Pears","Pomegranate","Raspberry","Strawberry","Water Melon",
                "Almonds","Pista","Nuts Mixture","Cashews","Walnuts"};
			
		int a= itemsNeeded.length;
		ArrayList list=new ArrayList();
		for (int i=0; i<a; i++) {
			list.add(itemsNeeded[i]);	
		}
		System.out.println(list);
	
	}

}
