package lists_practice;
import java.util.ArrayList;
import java.util.Scanner;
public class lists_basics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();
		for (int i=0; i<a; i++) {
			String b= sc.next();
			list.add(b);
		}
		System.out.println(list);
	}
}