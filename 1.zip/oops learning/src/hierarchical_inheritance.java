class food{  
	void prepare(){System.out.println("I'm preparing food...");}  
}

class items extends food{  
	void items(){System.out.println("different items is going to be prepared...");}  
}  
class drinks extends food{  
	void drinking(){System.out.println("drinking water...");}  
}  

class hierarchical_inheritance{  
	public static void main(String args[]){  
		drinks c=new drinks();  
		c.prepare();  
//		c.items();  
		c.drinking();//C.T.Error  
}}  
