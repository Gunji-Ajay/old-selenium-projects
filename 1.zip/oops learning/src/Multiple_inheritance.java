class forest{
	public String Def() {
		return "it is an area of land dominated by trees...";
	}
	
}
class animals extends forest{
	public String attack() {
		return "attack very easily...";
	}
	
}
class run extends animals{
	public String run() {
		return "running....";
	}
}

public class Multiple_inheritance {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		run r=new run();
		System.out.println(r.Def());
		System.out.println(r.attack());
		System.out.println(r.run());
		
	}

}


