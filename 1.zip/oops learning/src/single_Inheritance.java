class animal{
	public String eat() {
		return "eating...";
	}
	
}
class dog extends animal{
	public String run() {
		return "running...";
	}
	
}


public class single_Inheritance {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog r=new dog();
		System.out.println(r.run());
		System.out.println(r.eat());
	}

}
