package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class sendMail {
	WebDriver driver;
	
	public sendMail(WebDriver driver) {
		this.driver=driver;
	}
	public WebElement mailbtnclick() {
		return driver.findElement(By.xpath("//div[@title='Mail']"));
	}
	public WebElement compose() {
		return driver.findElement(By.xpath("//a[@role='button']"));
	}
	public WebElement tomail() {
		return driver.findElement(By.id("message-to-field"));
	}
	public WebElement subject() {
		return driver.findElement(By.xpath("//input[@data-test-id='compose-subject']"));
	}
	public WebElement message() {
		return driver.findElement(By.xpath("//div[@data-test-id='rte']"));
	}
	
	public WebElement send() {
		return driver.findElement(By.xpath("//button[@data-test-id='compose-send-button']"));
	}
	
}
