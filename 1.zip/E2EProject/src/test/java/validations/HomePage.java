package validations;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObject.landingPage;
import pageObject.login;
import pageObject.sendMail;
import resources.base;

public class HomePage extends base{
	public WebDriver driver;
	private static Logger log=LogManager.getLogger(base.class.getName());

	
	@BeforeTest
	public void before() throws IOException {
		driver = initialization();
		driver.get(prop.getProperty("url"));
	}

	@Test (dataProvider="getdata")
	public void firsttrail(String username,String pass,String to,String subject,String body) throws IOException, InterruptedException 
	{
		landingPage main=new landingPage(driver); //landing page
		main.button().click();
		
		login lg=new login(driver); //login page
		lg.email().sendKeys(username);
		lg.emailclick().click();
		lg.password().sendKeys(pass);
		lg.passwordclick().click();
		
		sendMail send=new sendMail(driver); //send mail page
		send.mailbtnclick().click();
		send.compose().click();
		send.tomail().sendKeys(to);
		send.subject().sendKeys(subject);
		send.message().sendKeys(body);
		send.send().click();
		log.info("successfully assigned the values");
		
	}
	@DataProvider
	public Object[][] getdata() {
		Object[][] data=new Object[1][5];
		data[0][0]="prasanthkovvela1";
		data[0][1]="8096149628";
		data[0][2]="prasanthkovvela1@gmail.com";
		data[0][3]="E2EProject training by prasanthkovvela";
		data[0][4]="hello prasanthkovvela how are you here i'm checking page object model";
		return data;
	}
	
	
	@AfterTest
	public void After() throws IOException {
		driver.close();
	}
	
}
