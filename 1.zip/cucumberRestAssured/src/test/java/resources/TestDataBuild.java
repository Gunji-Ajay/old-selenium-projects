package resources;

import java.util.ArrayList;
import java.util.List;

import pojo.addPlace;
import pojo.location;

public class TestDataBuild {
	
	public addPlace AddPlacePayload(String name, String phoneNumber, String language, String location) {
		addPlace p = new addPlace();
		p.setAccuracy(50);
		p.setName(name);
		p.setPhone_number(phoneNumber);
		p.setAddress(location);
		p.setWebsite("https://rahulshettyacademy.com");
		p.setLanguage(language);
		
		List<String> mylist =new ArrayList<String>();
		mylist.add("shoe park");
		mylist.add("shop");
		p.setTypes(mylist);
		
		location l=new location();
		
		l.setLat(-38.383494);
		l.setLng(33.427362);
		p.setLocation(l);
		return p;
	}
	
	public String deleteplacePayload(String placeId) {
		return "{\r\n"
				+ "    \"place_id\":\""+placeId+"\"\r\n"
				+ "}";
	}
	
	public String updateplacePayload(String placeId) {
		return "{\r\n"
				+ "    \"place_id\": \""+placeId+"\",\r\n"
				+ "    \"key\":\"qaclick123\",\r\n"
				+ "    \"phone_number\": \"9553517308\",\r\n"
				+ "    \"address\": \"near high school, Magam\"\r\n"
				+ "    \r\n"
				+ "}";
	}
	

}
