public class IMPSTransfer extends FundTransfer{
	//write your code here	
	protected double balance;
	IMPSTransfer(String accountNumber,double balance){
		setAccountNumber(accountNumber);
		setBalance(balance);
	}
	@Override
	boolean transfer(double transfer) {
		balance=getBalance();
		double total=transfer+(0.02*transfer);
		if(total<balance) {
			balance=balance-total;
			setBalance(balance);
			return true;
		}
		else {
			return false;
		}
	}
}
