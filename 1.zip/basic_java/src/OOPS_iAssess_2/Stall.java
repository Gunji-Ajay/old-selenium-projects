package OOPS_iAssess_2;

public interface Stall {
    void display();
}
