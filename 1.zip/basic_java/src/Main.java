import java.util.Scanner;
public class Main {
	public static void main(String args[]) throws Exception {
		//write your code here
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your account Number:");
		String accountNumber=sc.next();
		System.out.println("Enter your account Number:");
		double balance=sc.nextDouble();
		System.out.println("Enter your account Number:");
		String category=sc.next();
		System.out.println("Enter your account Number:");
		double transfer=sc.nextDouble();
		switch(category) {
		case "1":
			NEFTTransfer n=new NEFTTransfer(accountNumber,balance);
			if(n.validate(transfer)==false) {
				System.out.println("Account number or transfer amount seems to be wrong");
			}
			else {
				boolean con=n.transfer(transfer);
				if(con==true)
				{
					System.out.println("success");
					System.out.println("remaining balance"+n.getBalance());
				}
				else {
					System.out.println("transfer not completed");
				}
			}
			break;
			
			
		case "2":
			IMPSTransfer i=new IMPSTransfer(accountNumber,balance);
			if(i.validate(transfer)==false) {
				System.out.println("Account number or transfer amount seems to be wrong");
			}
			else {
				boolean con=i.transfer(transfer);
				if(con==true)
				{
					System.out.println("success");
					System.out.println("remaining balance"+i.getBalance());
				}
				else {
					System.out.println("transfer not completed");
				}
			}
			break;	
			
			
		case "3":
			RTGSTransfer r=new RTGSTransfer(accountNumber,balance);
			if(r.validate(transfer)==false) {
				System.out.println("Account number or transfer amount seems to be wrong");
			}
			else {
				boolean con=r.transfer(transfer);
				if(con==true)
				{
					System.out.println("success");
					System.out.println("remaining balance"+r.getBalance());
				}
				else {
					System.out.println("transfer not completed");
				}
			}
			break;	
			
		}
	}
}
