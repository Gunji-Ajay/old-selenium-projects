package exam3;

public class TicketBooking {
	private String stageEvent;
	private String customer;
	private String noOfSeats;
	TicketBooking(String stageEvent,String customer,String noOfSeats){
		this.stageEvent=stageEvent;
		this.customer=customer;
		this.noOfSeats=noOfSeats;
	}
	public String getStageEvent() {
		return stageEvent;
	}
	public String getcustomer() {
		return customer;
	}
	public String getnoOfSeats() {
		return noOfSeats;
	}
	public void makePayment(Double amount) {
		System.out.println("Amount "+amount +" paid in cash");
	}
	public void makePayment(String walletNumber,Double amount1) {
		System.out.println("Amount "+amount1 +" paid using wallet number "+walletNumber);
	}
	public void makePayment(String creditCard,String cvv,String name,Double amount2) {
		System.out.println("Holder name:"+name);
		System.out.println("Amount "+amount2 +" paid using Master card");
		System.out.println("CVV:"+cvv);
	}
}