package exam3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the booking details");
		String bd = sc.nextLine();
		String[] details  =bd.split(",");
		TicketBooking tb = new TicketBooking(details[0],details[1],details[2]);
		System.out.println("Payment mode\n1.Cash payment\n2.Wallet payment\n3.Credit card payment");
		String n = sc.next();
		
		switch(n){
			case "1":
				System.out.println("Enter the amount");
				Double amount = sc.nextDouble();
				System.out.println("Stage event:"+tb.getStageEvent());
				System.out.println("Customer:"+tb.getcustomer());
				System.out.println("Number Of seats:"+tb.getnoOfSeats());
				tb.makePayment(amount);
				break;
			case "2":
				System.out.println("Enter the amount");
				Double amount1 = sc.nextDouble();
				System.out.println("Enter the wallet number");
				String walletNumber = sc.next();
				System.out.println("Stage event:"+tb.getStageEvent());
				System.out.println("Customer:"+tb.getcustomer());
				System.out.println("Number Of seats:"+tb.getnoOfSeats());
				tb.makePayment(walletNumber,amount1);
				break;
			case "3":
				System.out.println("Enter card holder name");
				String name = sc.next();
				System.out.println("Enter the amount");
				Double amount2 = sc.nextDouble();
				System.out.println("Enter the credit card type");
				String cardType = sc.next();
				System.out.println("Enter the CVV number");
				String cvv = sc.next();
				System.out.println("Stage event:"+tb.getStageEvent());
				System.out.println("Customer:"+tb.getcustomer());
				System.out.println("Number Of seats:"+tb.getnoOfSeats());
				tb.makePayment(cardType,cvv,name,amount2);
				break;
			default:
				System.out.println("Invalid choice");
		}
		sc.close();
	
	}

}