package Database;

import java.sql.*;
import java.util.*;
public class project_basic {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("please enter product_Id");
		int id=sc.nextInt();
		System.out.println("please enter product_name");
		String name=sc.next();
		System.out.println("please enter product_cost");
		int cost=sc.nextInt();
		System.out.println("please enter category");
		String cat=sc.next();
		
		
		Connection con= null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema", "root", "Kovvela1@");
			System.out.println("connected");
			System.out.println(con.getClass().getName());
		
			String Query="insert into ecommerce values(?,?,?,?)";
			PreparedStatement pstatement=con.prepareStatement(Query);
			pstatement.setInt(1, id);
			pstatement.setString(2, name);
			pstatement.setInt(3, cost);
			pstatement.setString(4, cat);
			
			int record = pstatement.executeUpdate();
			if(record>0) {
				System.out.println("Record updated\n1 row added to ecommerce table");
			}
			else {
				System.out.println("record not inserted");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			con.close();
		}
		sc.close();
		}
	
		
		
	}


