package Database;

import java.sql.*;


public class Basics {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/new_schema";
		String username="root";
		String pass="Kovvela1@";
		String query="SELECT * FROM new_schema.ecommerce";
		
		//Connection con= null;
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(query);
		while(rs.next()) {
			String name=rs.getString("product_name");
			System.out.println(name);
		}		
		st.close();
		con.close();
	}

}
