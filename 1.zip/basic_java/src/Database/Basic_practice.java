package Database;

import java.sql.*;

public class Basic_practice {

		public static void main(String[] args) throws Exception {
			// TODO Auto-generated method stub
			Connection con= null;
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema", "root", "Kovvela1@");
				System.out.println("connected");
				System.out.println(con.getClass().getName());
	
		}
	}
