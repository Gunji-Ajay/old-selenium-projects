package exam;
import java.util.Scanner; 
public class Main {
	
	public static void main(String args[]) throws Exception {
	
		Scanner sc= new Scanner(System.in);

				System.out.println("Enter your account number:");
				String accountNumber =sc.next();
				System.out.println("Enter the balance of the account:");
				 double balance=sc.nextDouble();
				System.out.println("Enter the type of transfer to be made:\n1.NEFT\n2.IMPS\n3.RTGS");
				String category=sc.next();
				System.out.println("Enter the amount to be transferred:");
				double transfer=sc.nextDouble();
				switch(category) {
				case "1":
					NEFTTransfer n=new NEFTTransfer(accountNumber,balance);
					if(n.validate(transfer)==false) {
						System.out.print("Account number or transfer amount seems to be wrong");
					}
					else {
					boolean con=n.transfer(transfer);
					if (con ==true)
					{
						System.out.println("Transfer occurred successfully");
						System.out.println("Remaining balance is "+n.getBalance());
					}
					else {
						System.out.println("Transfer could not be made");
					}
					}
					
					break;
				
				case "2":
					IMPSTransfer i=new IMPSTransfer(accountNumber,balance);
					if(i.validate(transfer)==false) {
						System.out.print("Account number or transfer amount seems to be wrong");
					}
					else {
					boolean con=i.transfer(transfer);
					if (con ==true)
					{
						System.out.println("Transfer occurred successfully");
						System.out.println("Remaining balance is "+i.getBalance());
					}
					else {
						System.out.println("Transfer could not be made");
					}
					}
					
					break;
				case "3":
					RTGSTransfer r=new RTGSTransfer(accountNumber,balance);
					if(r.validate(transfer)==false) {
						System.out.print("Account number or transfer amount seems to be wrong");
					}
					else {
					boolean con=r.transfer(transfer);
					if (con ==true)
					{
						System.out.println("Transfer occurred successfully");
						System.out.println("Remaining balance is "+r.getBalance());
					}
					else {
						System.out.println("Transfer could not be made");
					}
					}
					
					break;
				}	
				
	}
}