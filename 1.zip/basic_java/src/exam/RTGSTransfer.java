package exam;
public class RTGSTransfer extends FundTransfer {
	protected double balance;
	RTGSTransfer(String accountNumber,double balance){
		setAccountNumber(accountNumber);
		setBalance(balance);
		
	}
	
	@Override
	boolean transfer(double transfer) {
		balance=getBalance();
		
		if(transfer<balance && transfer>10000) {
			balance=balance-transfer;
			setBalance(balance);
			return true;
		}
		else
			{
			    return false;
			}
	}
	
}