package pract1;
import java.util.Scanner;

public class Nested_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		
		double a= sc.nextDouble();
		
		if (a%2 == 0){
			if (a<=50) {
				System.out.println("given input is even and less than 50");
			}
			else {
				System.out.println("given input is even and greater than 50");	
			}
			
		}
		else {
			System.out.println("odd");
		}
		sc.close();
		

	}

}
