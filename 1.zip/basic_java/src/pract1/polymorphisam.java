package pract1;
public class polymorphisam {
	public static void add(int a, int b) {
		System.out.println(a+b);
		
	}
	public static void add(String first, String last) {
		System.out.println(first+last);
		
	}
	public static void add(int a, int b, int c, int d) {
		System.out.println(a+b+c+d);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String first= "prasanth ", 
		last="Kovvela";
		
		int a=10, b=20, c=30, d=40;
		
		
		add(first, last);
		add(a,b,c,d);
		add(a,b);
	}

}
