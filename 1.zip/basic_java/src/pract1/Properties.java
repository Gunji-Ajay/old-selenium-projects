package pract1;
import java.io.*;
public class Properties {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
	
		Properties prop = new Properties();
		FileInputStream fis=new FileInputStream("D:\\prasanth.properties");
	try {
		prop.load(fis);
		String val1 = prop.getProperty("username");
		String val2 = prop.getProperty("passward");
		String val3 = prop.getProperty("database");
		
		System.out.println("Value 1: "+val1);
		System.out.println("Value 2: "+val2);
		System.out.println("Value 3: "+val3);
	}catch(IOException e){
		e.printStackTrace();
	}
		
	}
	
}
