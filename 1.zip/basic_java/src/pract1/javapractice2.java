package pract1;

public class javapractice2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double a=5, b=6;
		System.out.println("Area of triangle = " +0.5*a*b);
	}

}
