package pract1;
class dog{
	void dog_barging(){
		System.out.println("bow bow");
	}
}
class cat extends dog{
	void cat_caging(){
		System.out.println("meow meow");
	}
}
class cow extends cat{
	void cow_barging(){
		System.out.println("amba amba");
	}
}

public class Multilevel_inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		cow d=new cow();
		d.dog_barging();
		d.cat_caging();
		d.cow_barging();
	}

}
