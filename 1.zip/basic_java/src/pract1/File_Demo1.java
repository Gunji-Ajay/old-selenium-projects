package pract1;
import java.io.*;
public class File_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File name=new File("D:\\Demo.txt");
		if (name.exists()){
			System.out.println(name.getName());
			System.out.println(name.getAbsolutePath());
			System.out.println(name.length());
			System.out.println(name.canRead());
			System.out.println(name.canWrite());
		}
		else {
			System.out.println("file not exists");
		}
		
	}

}
