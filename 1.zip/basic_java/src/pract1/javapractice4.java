package pract1;

import java.util.Scanner;

public class javapractice4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("please enter salary amout and number of leave u want");
		Scanner sc= new Scanner(System.in);
		double salary=sc.nextDouble();
		int leaves=sc.nextInt();
		int totalDays=31;
		System.out.println(salary/totalDays*(totalDays-leaves));
		sc.close();
	}

}
