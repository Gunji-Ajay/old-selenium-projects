package pract1;
import java.util.Scanner;
public class For_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number of products");
		int a=sc.nextInt();
		double bill=0;
		for (int i=1; i<=a; i++){
			System.out.println("enter "+i+"st item price");
			double price=sc.nextDouble();
			System.out.println("enter "+i+"st item discount");
			double discount =sc.nextDouble();
			bill=bill+(price-(price/discount));
		}
		System.out.print("total bill is: "+bill);		
		sc.close();
	}

}
