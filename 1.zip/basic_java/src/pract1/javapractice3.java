package pract1;

public class javapractice3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double salary=15000;
		double day_count=salary/31;
		
	    System.out.println("Remaining salary after taking 3 leaves = " + (salary-(day_count*3)));
	}

}
