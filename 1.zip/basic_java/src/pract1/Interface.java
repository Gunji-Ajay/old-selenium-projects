package pract1;
interface Animal01{
	public void eating();
	public void running();
}
class pig implements Animal01
{
	public void eating() {
		System.out.println("pig is eating...");
	}
	public void running() {
		System.out.println("pig is running...");
	}
}
public class Interface {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pig mypig=new pig();	
		mypig.running();
		mypig.eating();
	}
}
