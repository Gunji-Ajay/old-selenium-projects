package pract1;
import java.util.Scanner;
public class Pattern_pract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();
		for(int i=1; i<=a; i++) {
			for(int j=i; j<=a; j++) {	
				System.out.print(j+ " ");
			}
			System.out.println();
			
		}	
		sc.close();
	}

}
