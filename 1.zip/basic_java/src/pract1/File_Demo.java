package pract1;

import java.io.*;

public class File_Demo {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		try {
			File name=new File("D:\\Demo.txt");
			if(name.createNewFile()) {
				System.out.println("file created");
			}
			else {
				System.out.println("file is already existed");
			}
		}catch(IOException e) {
			System.out.println("an error occured");
			e.printStackTrace();
		}
			
	}
}
