package pract1;

public class Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="prasanth";
		char ch=a.charAt(5);
		System.out.println(ch);
		
		int A=10,b=0,c;
		try 
		{
			c=A/b;
			System.out.println(c);
			
			String k="prasanth";
			char CH=k.charAt(10);
			System.out.println(ch);
					
		}
		catch(Exception e){
			System.out.println("b must be greater than or equal to 1");
		}
		catch(addition e) {
			System.out.print("helloooo");
		}
		
	}

}
