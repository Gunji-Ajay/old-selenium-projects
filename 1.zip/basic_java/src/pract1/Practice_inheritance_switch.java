package pract1;

class language{
	
	public void displayInfo() {
		System.out.println("common english language");
	}
}

class java1 extends language{
	public void displayInfo()
	{
		super.displayInfo();
		System.out.println("java programming language");
	}
}

class Practice_inheritance_switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		language j1=new java1();
		j1.displayInfo();
	}

}
