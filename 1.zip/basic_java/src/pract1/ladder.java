package pract1;

import java.util.Scanner;

public class ladder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in); 
		
		double a= sc.nextDouble();
		if (a<=30)
			System.out.println("Fail");
		else if (a>30 &&  a<=40)
			System.out.println("Just Pass");	
		else if (a>40 && a<=50)
			System.out.println("Third Class");
		else if (a>50 && a<=60)
			System.out.println("Second Class");
		else if ((a>60) && (a<=70))
			System.out.println("First Class");
		else
			System.out.println("Distinction");
		sc.close();
	}
	

}
