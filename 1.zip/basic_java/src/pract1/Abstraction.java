package pract1;

abstract class bike{
	bike(){
		System.out.println("bike is getting ready");
	}
	abstract void run();
	void gear() {
		System.out.println("changing gear");
	}
}

class honda extends bike {
	void move() {
		System.out.println("moving bike");
	}
class abstract_bike{
	public void main(String[] args) {
		// TODO Auto-generated method stub
		
		bike a= new honda();
		a.gear();
		
		

	}
}


}
