package pract1;
import java.util.Scanner;
class Employee{
	public static int total(int maths1,int maths2,int physics,int chemistry) {
		int totalmarks=maths1+maths2+physics+chemistry;	
		return totalmarks;
	}
	public static int total(int eng,int san,int civics,int history ,int economics) {
		int totalmarks=eng+san+civics+history+economics;	
		return totalmarks;
	}
	public static int total(int s1,int s2,int s3) {
		int totalmarks=s1+s2+s3;	
		return totalmarks;
	}
	
	public static void percentage(int totalmarks,int fullmarks)
	{
		int percentage=((totalmarks*100)/fullmarks);
		System.out.println("percentage is "+percentage);
		
		if (percentage<=30)
			System.out.println("Fail");
		else if (percentage>30 &&  percentage<=40)
			System.out.println("Just Pass");	
		else if (percentage>40 && percentage<=50)
			System.out.println("Third Class");
		else if (percentage>50 && percentage<=60)
			System.out.println("Second Class");
		else if ((percentage>60) && (percentage<=70))
			System.out.println("First Class");
		else
			System.out.println("Distinction");
	}
}

public class inheritance extends Employee {
	
	public static void val(int a) {
		Scanner sc= new Scanner(System.in);
		switch (a)
		{
			case 1:
			{
				System.out.println("enter your four subject marks");
				int maths1=sc.nextInt();
				int maths2=sc.nextInt();
				int physics=sc.nextInt();
				int chemistry=sc.nextInt();
				int marks=total(maths1,maths2,physics,chemistry);
				int fullmarks=200;
				percentage(marks,fullmarks);
				break;
			}
			case 2:
			{
				System.out.println("enter your five subject marks");
				int eng =sc.nextInt();
				int san=sc.nextInt();
				int civics=sc.nextInt();
				int history=sc.nextInt();
				int economics=sc.nextInt();
				int marks=total(eng,san,civics,history,economics);
				int fullmarks=250;
				percentage(marks,fullmarks);
				break;	
			}
			case 3:
			{
				System.out.println("enter your three subject marks");
				int s1=sc.nextInt();
				int s2=sc.nextInt();
				int s3=sc.nextInt();
				int marks=total(s1,s2,s3);
				int fullmarks=150;
				percentage(marks,fullmarks);
				break;
			}
			default:
				System.out.println("Please enter proper input");
		} 
		sc.close();	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter your stream\n1.sciencen\n2.commerce\n3.arts");
		int a=sc.nextInt();
		val(a);
		sc.close();		
	}
}
