package pract1;
import java.util.Scanner;
class account1{
	private long ac;
	private String name,email;
	private float amount;
	
	public void setAcc(long ac) 
	{
		this.ac=ac;
	}
	public void setEmail(String email) 
	{
		this.email=email;
	}
	public void setName(String name) 
	{
		this.name=name;
	}
	public void setAmount(float amount) 
	{
		this.amount=amount;
	}
	public String getA() {
		return email;
	}
	public String getB() {
		return name;
	}
	public float getC() {
		return amount;
	}
	public long getD() {
		return ac;
	}
	
}

public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner (System.in);
		account1 myAcc= new account1();
		
		System.out.println("enter your ac number");
		long ac=sc.nextLong();
		myAcc.setAcc(ac);
		myAcc.setName("PrasanthKovvela");
		myAcc.setEmail("prasanthkovvela1@gmail.com");
		myAcc.setAmount(25000f);
		System.out.println("your mailId: "+myAcc.getA());
		System.out.println("your Name: "+myAcc.getB());
		System.out.println("your remaining balance : "+myAcc.getC()+ " \nin "+myAcc.getD()+" Ac number");
		
		sc.close();
	}

}
