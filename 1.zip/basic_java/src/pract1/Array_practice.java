package pract1;
import java.util.Scanner;
public class Array_practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Scanner sc= new Scanner(System.in); 
			int a=sc.nextInt(); 
			int array[]= new int[a]; 
			for(int i=0; i<a; i++)  

			{ 

				array[i]=sc.nextInt(); 

			} 
			for (int num:array) {
				System.out.print(num+" ");
			}
			sc.close();
	}

}
