package pract1;

import java.util.Scanner;

class Subject{
	
}


public class Practice_inheritance{
	
	public static int total(int maths1,int maths2,int physics,int chemistry) {
		int totalmarks=maths1+maths2+physics+chemistry;	
		return totalmarks;
	}
	public static int total(int eng,int san,int civics,int history ,int economics) {
		int totalmarks=eng+san+civics+history+economics;	
		return totalmarks;
	}
	public static int total(int s1,int s2,int s3) {
		int totalmarks=s1+s2+s3;	
		return totalmarks;
	}
	
	public static void percentage(int totalmarks,int fullmarks)
	{
		int percentage=((totalmarks*100)/fullmarks);
		System.out.println("percentage is "+percentage);
		
		if(percentage>=75 && percentage<100) 
		{
			System.out.println("grade A");
		}
		else if(percentage>=50 && percentage<75) {
		System.out.println("grade B");
		}
		else if(percentage>=35 && percentage<50) 
		{
			System.out.println("grade c");
		}
		else 
		{
			System.out.println("FAIL");
		}	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your stream\n 1.sciencen\n 2.commerce\n 3.arts");
		int choice=sc.nextInt();
		switch (choice)
		{
			case 1:
			{
				System.out.println("enter your four subject marks");
				int maths1=sc.nextInt();
				int maths2=sc.nextInt();
				int physics=sc.nextInt();
				int chemistry=sc.nextInt();
				int marks=total(maths1,maths2,physics,chemistry);
				int fullmarks=270;
				percentage(marks,fullmarks);
				break;
				
				
			}
			case 2:
			{
				System.out.println("enter your five subject marks");
				int eng =sc.nextInt();
				int san=sc.nextInt();
				int civics=sc.nextInt();
				int history=sc.nextInt();
				int economics=sc.nextInt();
				int marks=total(eng,san,civics,history,economics);
				int fullmarks=500;
				percentage(marks,fullmarks);
				break;	
			}
			case 3:
			{
				System.out.println("enter your three subject marks");
				int s1=sc.nextInt();
				int s2=sc.nextInt();
				int s3=sc.nextInt();
				int marks=total(s1,s2,s3);
				int fullmarks=300;
				percentage(marks,fullmarks);
				break;
			}
		} 
		sc.close();     
	}

}

