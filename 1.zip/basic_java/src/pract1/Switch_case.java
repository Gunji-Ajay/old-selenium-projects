package pract1;
import java.util.Scanner;
public class Switch_case {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("1. addition\n2. subtraction\n3. multiplication\n4. division\n5. modulus");
		Scanner sc= new Scanner(System.in);
		System.out.println("select one operation");
		int a= sc.nextInt();
		System.out.println("enter two number");
		int b= sc.nextInt();
		int c= sc.nextInt();
		
		switch(a)
		{
			case 1:
			{
				System.out.println("adding 2 numbers = "+(b+c));
				break;
			}
			case 2:
			{
				System.out.println("adding 2 numbers = " +(b-c));
				break;
			}
			case 3:
			{
				System.out.println("adding 2 numbers = "+(b*c));
				break;
			}
			case 4:
			{
				System.out.println("adding 2 numbers = "+(b/c));
				break;
			}
			case 5:
			{
				System.out.println("adding 2 numbers = "+ (b%c));
				break;
			}
			default:
			{
				System.out.println("please enter valid numbers");
			}		
		}
		sc.close();
		
	}

}
