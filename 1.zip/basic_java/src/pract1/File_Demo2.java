package pract1;

import java.io.*;

public class File_Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileWriter content=new FileWriter("D:\\demo.txt");
			content.write("hello world");
			content.close();
			System.out.println("successfully updated");
		}
		catch(IOException e){
			System.out.println("error occured");
		}
		
	}

}
