package pract1;
import java.util.Scanner;
class user{
	Scanner sc= new Scanner(System.in);
	public static double tds(double salary) {
		return (salary/10);
	}
	public static double leave(double salary, double leaves) {
		double day=(salary/31);
		return (day*leaves);
	}
	
}
public class Inheritance_salary extends user{
	public static double calculate(double tds_amount, double salary, double leave_deduction) {
		return salary-(tds_amount+leave_deduction);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.print("enter monthly salary");
		double salary=sc.nextDouble();
		Inheritance_salary d= new Inheritance_salary();
		double tds_amount=Inheritance_salary.tds(salary);
		System.out.println("10% TDS: "+tds_amount);		
		System.out.print("enter number of leaves");
		double leaves=sc.nextInt();
		double leave_deduction=Inheritance_salary.leave(salary, leaves);
		System.out.println("leaves deduction: "+leave_deduction);
		System.out.println("Salary per day after leaves: "+(salary/31));
		double net_salary=Inheritance_salary.calculate(tds_amount, salary, leave_deduction);
		System.out.println("Net Salary after all Cuttings: "+net_salary);
	}

}	
