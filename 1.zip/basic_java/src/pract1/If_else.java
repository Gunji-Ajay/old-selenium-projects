package pract1;
import java.util.Scanner;
public class If_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter your age");
		int a = sc.nextInt();
		
		if (a >= 21)
		{
			System.out.println("person is  eligible for home loan");
		}
		else
		{
			System.out.println(" person is not eligible for home loan");
		}
		
		sc.close();
	}

}
