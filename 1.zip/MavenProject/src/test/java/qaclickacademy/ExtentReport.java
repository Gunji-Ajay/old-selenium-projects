package qaclickacademy;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {
ExtentReports extent;
	
	@BeforeTest
	public ExtentReports Configuration() 
	{
		String path=System.getProperty("user.dir")+"\\reports\\index.html";
		
		ExtentSparkReporter report=new ExtentSparkReporter(path);
		report.config().setDocumentTitle("Test Results");
		report.config().setReportName("web Automation testing");
		
		extent=new ExtentReports();
		extent.attachReporter(report);
		extent.setSystemInfo("tester", "Prasanth Kovvela");
		return extent;
	}
	
	@Test
	public void getBrowser()
	{
		extent.createTest("Initial Demo");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.youtube.com/");
		System.out.println(driver.getTitle());
		driver.close();
		extent.flush();
				
	}

}
