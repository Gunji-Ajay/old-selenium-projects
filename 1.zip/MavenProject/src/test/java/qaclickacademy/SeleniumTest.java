package qaclickacademy;

import org.testng.annotations.Test;

public class SeleniumTest {
	@Test
	public void SeleniumTest1() {
		System.out.println("SeleniumTest1");
	}
	
	@Test
	public void SeleniumTest2() {
		System.out.println("SeleniumTest2");
	}
}