package qaclickacademy;

import org.testng.annotations.Test;

public class RESTAPITest {
	@Test
	public void RESTAPITest1() {
		System.out.println("RESTAPITest1");
	}
	
	@Test
	public void RESTAPITest2() {
		System.out.println("RESTAPITest2");
	}
}
