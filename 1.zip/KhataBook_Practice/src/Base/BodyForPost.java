package Base;

public class BodyForPost {
	
	public static String body() {
		return "{\r\n"
				+ "\"location\":{\r\n"
				+ "\"lat\":-38.383494,\r\n"
				+ "\"lng\":33.427362\r\n"
				+ "},\r\n"
				+ "\"accuracy\":50,\r\n"
				+ "\"name\":\"Prasanth Kovvela\",\r\n"
				+ "\"phone_number\":\"9553377308\",\r\n"
				+ "\"address\":\"4-89,MainRoad,Magam\",\r\n"
				+ "\"types\":[\r\n"
				+ "\"shoe park\",\r\n"
				+ "\"shop\"\r\n"
				+ "],\r\n"
				+ "\"website\":\"https://rahulshettyacademy.com\",\r\n"
				+ "\"language\":\"French-IN\"\r\n"
				+ "}";
	}
	
	
	
	public static String coursesbody() {
		return "{\r\n"
				+ "    \"dashboard\": {\r\n"
				+ "        \"purchaseAmount\":910,\r\n"
				+ "        \"website\": \"rahulshettyacademy.com\"\r\n"
				+ "    },\r\n"
				+ "    \"courses\":[\r\n"
				+ "        {\r\n"
				+ "            \"title\": \"Selenium Python\",\r\n"
				+ "            \"price\": 50,\r\n"
				+ "            \"copies\": 6\r\n"
				+ "        },\r\n"
				+ "        {\r\n"
				+ "            \"title\": \"Cypress\",\r\n"
				+ "            \"price\": 40,\r\n"
				+ "            \"copies\": 4\r\n"
				+ "        },\r\n"
				+ "        {\r\n"
				+ "            \"title\": \"RPA\",\r\n"
				+ "            \"price\": 45,\r\n"
				+ "            \"copies\": 10\r\n"
				+ "        }\r\n"
				+ "    ]\r\n"
				+ "\r\n"
				+ "}";
	}
	public static String addBook(String first, String second) {
		return "{\r\n"
				+ "    \"name\":\"learn Appium Automation\",\r\n"
				+ "    \"isbn\":\""+first+"\",\r\n"
				+ "    \"aisle\": \""+second+"\",\r\n"
				+ "    \"author\":\"John foe\"\r\n"
				+ "}";
	}
	public static String newbody(String placeId) {
		// TODO Auto-generated method stub
		return "{\r\n"
		+ "    \"place_id\": \""+placeId+"\",\r\n"
		+ "    \"key\":\"qaclick123\",\r\n"
		+ "    \"phone_number\": \"9553517308\",\r\n"
		+ "    \"address\": \"Near high school, MainRoad, Magam\"\r\n"
		+ "    \r\n"
		+ "}";
	}
	
}
