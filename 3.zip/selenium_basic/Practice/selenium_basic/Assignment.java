package selenium_basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		Select brand=new Select(driver.findElement(By.xpath("//select[@name='make']")));
		brand.selectByIndex(2);
		System.out.println("You have Selected Audi");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//p/input[@name='fuel_type' and @value='Diesel']")).click();
		System.out.println("You have Selected Diesel Varient in Audi ");
		Thread.sleep(1000);
		
		WebElement LED= driver.findElement(By.xpath("//input[@type='checkbox' and @name='ledheadlamp']"));
		if (LED.isEnabled())
			System.out.println("LED is Enabled");
			
		else
			System.out.println("LED IS Disabled");
		
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='abs']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='airbags']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='parksensor']")).click();
		System.out.println("Some Optional features are: Abs, Airbags, ParkingSensors");
		Thread.sleep(1000);
		
		
		driver.findElement(By.xpath("//option[@value='wt']")).click();
		driver.findElement(By.xpath("//option[@value='br']")).click();
		System.out.println("You have Choosen White and Brown colours");
		
		
		
		Thread.sleep(3000);
		driver.close();	
		
		////input[@type='checkbox' and @name='abs']
	}

}
