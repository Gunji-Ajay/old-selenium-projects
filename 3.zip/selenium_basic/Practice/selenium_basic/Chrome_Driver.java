package selenium_basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Chrome_Driver {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		System.out.println(driver.getTitle());
		WebElement searchBox=driver.findElement(By.name("q"));
		searchBox.sendKeys("youtube");
		driver.findElement(By.name("btnK")).submit();
		Thread.sleep(5000);
		driver.navigate().back();
		Thread.sleep(2000);
		
		driver.navigate().forward();
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		
		driver.getWindowHandle();
		Thread.sleep(2000);
		
		driver.navigate().to("https://en.wikipedia.org/wiki/Main_Page");
		Thread.sleep(2000);
		driver.close();
	}
}
