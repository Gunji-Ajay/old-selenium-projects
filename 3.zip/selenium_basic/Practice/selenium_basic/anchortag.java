package selenium_basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class anchortag {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.wikipedia.org/");
		Thread.sleep(2000);
		driver. findElement(By. xpath("//strong[contains(text(),'English')]")).click();
	}

}
