package selenium_basic;

public class Random_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int min = 1;  
		int max = 500;
		double a = (Math.random());  
		double b=(Math.random());
		System.out.println(a);
		System.out.println(b);
		  
	}
	

}
