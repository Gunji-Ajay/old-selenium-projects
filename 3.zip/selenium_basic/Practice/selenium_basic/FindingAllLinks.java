package selenium_basic;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindingAllLinks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		List<WebElement> linkNames=driver.findElements(By.tagName("a"));
		int size=linkNames.size();
		System.out.println(linkNames);
		System.out.println("Total Number of links in www.google.com: "+linkNames.size());
		for(int i=0; i<size; i++) 
			System.out.println(linkNames.get(i)); 
			driver.quit(); 
	}

}
