package restAPI;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Base.BodyForPost;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class retriveData {

	@BeforeTest
	public void url() {
		RestAssured.baseURI="https://rahulshettyacademy.com";
	}
	
	String placeId;
	@Test(priority=1)
	public void post() {

		String response1=given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json").body(BodyForPost.body()).when().post("maps/api/place/add/json").then().assertThat().log().all().statusCode(200)
		.body("scope", equalTo("APP")).header("Server", "Apache/2.4.41 (Ubuntu)").extract().response().asString();
		System.out.println(response1);
		JsonPath js=new JsonPath(response1);
		placeId=js.getString("place_id");
		System.out.println("postPlaceId = "+placeId);
	}
	
	@Test(priority=2)
	public void get() {	
		String response2=given().log().all().queryParam("key", "qaclick123").queryParam("place_id", placeId).when().get("maps/api/place/get/json").then().assertThat().log().all().statusCode(200).extract().response().asString();
		System.out.println(response2);
		JsonPath js1=new JsonPath(response2);
		String address=js1.getString("phone_number");
		System.out.println(address);
	}
	
	@Test(priority=3)
	public void update() {
//		JSONObject request=new JSONObject();
//		request.put("place_id", placeId);
//		request.put("key", "qaclick123");
//		request.put("phone_number", "9553577308");
//		request.put("address", "Near high school, MainRoad, Magam");
		
		given().log().all().queryParam("key", "qaclick123").queryParam("place_id", placeId).header("Content-Type", "application/json")
		.body(BodyForPost.newbody(placeId)).when().put("maps/api/place/update/json").then().assertThat().log().all().statusCode(200).body("msg", equalTo("Address successfully updated"));
	}
	
	@Test(priority=4)
	public void delete() {
		JSONObject request=new JSONObject();
		request.put("place_id", placeId);
		given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
		.body(request.toJSONString()).when().delete("maps/api/place/delete/json").then().assertThat().log().all().statusCode(200);
	}
	
	@Test(priority=5)
	public void getDeletedData() {
	given().log().all().queryParam("key", "qaclick123").queryParam("place_id", placeId).when().get("maps/api/place/get/json").then().assertThat().log().all().statusCode(404).body("msg", equalTo("Get operation failed, looks like place_id  doesn't exists"));
	}	

}
